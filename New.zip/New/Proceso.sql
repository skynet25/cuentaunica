----Solicitud de Informaci�n de Gesti�n N� 00060 - 2018 - 7B2300
--
--Buen d�a:
--.
--Me dirijo a usted en atenci�n al Oficio N� 104-2018-MATM/CR (Exp. 2018-161752-3) suscrito por el Congresista de la Rep�blica,
-- Sr. Miguel Torres Morales, quien solicita se le proporcione informaci�n de las multas emitidas en los a�os 2016 y 2017,
--  seg�n los siguientes criterios:
--.
--1. La informaci�n es por cada r�gimen tributario (R�gimen General, R�gimen MYPE Tributario (RMT),
-- R�gimen Especial de Renta IRERI, R�gimen �nico Simplificado (RUS), Rentas de Cuarta categor�a y otros reg�menes).
--  Trat�ndose de los contribuyentes del R�gimen General la informaci�n se requiere identificando el tama�o del contribuyente
--   (Mega, TOP, Grande, Mediano, peque�o y microempresa).
--.
--2. Respecto de cada tipo de infracci�n se�alada en el C�digo Tributario se requiere la siguiente
-- informaci�n: cantidad de contribuyentes involucrados seg�n el punto 1, n�mero de multas emitidas,
--  importe insoluto de las multas emitidas, intereses de las multas emitidas, monto total de multas emitidas, monto pagado al cierre del a�o por dichas multas, monto impugnado al cierre del a�o por las multas.
--.
--3. Respecto de la informaci�n se�alada en el punto 2 y respecto de los contribuyentes se�alados en
-- el punto 1, se requiere la informaci�n acumulada (hist�rica) al 31 de diciembre del 2017.
--.
--A efectos de dar atenci�n a los indicados pedidos, agradeceremos se sirvan remitirnos los Cuadros
-- con la informaci�n requerida, los mismos que ser�n anexados al Informe de Intendencia y Oficio de respuesta dirigido al indicado congresista.

--  tipo de documento RM
Select distinct cod_doc from db_gpgd.dbo.Param_Tipo_Doc where tipo='RM'

-- Valores emitidos por a�o
select a�o,count(*) from db_gpgd.dbo.TBL_Valores_Emitidos group by  a�o order by a�o desc
--2017	1965413
--2016	2358561

-- Valores emitidos para los a�os 2016 y 2017
select * from db_gpgd.dbo.TBL_Valores_Emitidos where a�o in ('2016','2017')  ------4,323,974
select * from db_gpgd.dbo.TBL_Valores_Emitidos where  year(fec_emi) in ('2016','2017');--  4321279

--drop table [db_proc_procesos1].[n570].[memo60]
-- Valores emitidos para los a�os 2016 y 2017 con RM
select * 
--into [db_proc_procesos1].[n570].[memo60]
from db_gpgd.dbo.TBL_Valores_Emitidos 
where year(fec_emi) in ('2016','2017') and cod_doc in (Select distinct cod_doc from db_gpgd.dbo.Param_Tipo_Doc where tipo='RM');
-- 405,149 filtro a�o
-- 402,589 fec_emi

-- drop table [db_proc_procesos1].[n570].[memo601] 
select * 
--into [db_proc_procesos1].[n570].[memo601]
 from [db_proc_procesos1].[n570].[memo60];

--select * from [db_proc_procesos1].[n570].[memo601];

-- Agregando campos a la tabla 
alter table [db_proc_procesos1].[n570].[memo601] add codRegimen char(6);
update a
set codRegimen=id_subtipregim
from [db_proc_procesos1].[n570].[memo601] a, db_analisis.padron.dim_Contribuyente b
where a.ruc=b.num_ruc;
---(402589 row(s) affected)

--- asigando nuevos campos y valores
select top 100 * from db_analisis.padron.dim_Contribuyente; ---- codigo de regimen
select * from db_analisis.padron.dim_RegimenContri; -- descripcion de regimen  
Select * from db_gpgd.dbo.Param_Categorias --- descripcion de tama�o  - tabla parametrica de categorias 

--drop table [db_proc_procesos1].[n570].[memo602]
select t1.[dep],t1.[ruc],t1.[est_ruc],t1.[cond_dom],t1.[ciiu],t1.[cod_ori],t1.[cod_doc],
t1.[cod_valor],t1.[areaco],t1.[per_trib],t1.[cod_trib],t1.[cod_trib_aso],t1.[fec_emi],
t1.[mto_trib],t1.[mto_int],t1.[mto_cap],t1.[exp_coa],t1.[ord_fis],t1.[num_proc],t1.[cod_proc],
t1.[cod_subproc],t1.[cod_cta],t1.[fec_not],t1.[fecreg_not],t1.[fec_vcto],t1.[cod_usu],
t1.[fec_reg],t1.[ubigeo],t1.[categoria],t1.[tama�o],t1.[contrib],t1.[sector],
t1.[mes],t1.[a�o],t1.[fec_act],t1.[bc],t1.[codRegimen],
t2.des_subtipregim as des_Regimen,
t3.nom_segfisca as des_tama�o
into [db_proc_procesos1].[n570].[memo602]
from [db_proc_procesos1].[n570].[memo601] t1
left join db_analisis.padron.dim_RegimenContri t2 on t1.[codRegimen]=t2.id_subtipregim
left join db_gpgd.dbo.Param_Categorias t3 on t1.[tama�o]=t3.id_segfisca;

--- Pedido 1  ---(402589 row(s) affected)
select * from [db_proc_procesos1].[n570].[memo602];

select [codRegimen],des_Regimen, count(*)
from [db_proc_procesos1].[n570].[memo602]
group by [codRegimen],des_Regimen

--drop table [db_proc_procesos1].[n570].[memo60_1]
select RUC, cod_valor,[codRegimen], des_Regimen,tama�o,des_tama�o,a�o
--into [db_proc_procesos1].[n570].[memo60_1]  ---(402589 row(s) affected)
from [db_proc_procesos1].[n570].[memo602];

/*******************************************	Asignar codigos	************************************************************/
--drop table [db_proc_procesos1].[n570].[memo60_1f]
select 
DENSE_RANK() over(order by RUC ) RUC_R,RUC, 
ROW_NUMBER() over(order by cod_valor) Nro_Valor, cod_valor,
[codRegimen], des_Regimen,tama�o,des_tama�o,a�o 
--into [db_proc_procesos1].[n570].[memo60_1f]  ---(402589 row(s) affected)
from [db_proc_procesos1].[n570].[memo60_1]
order by 1, 2 desc;

--drop table [db_proc_procesos1].[n570].[memo60_2f] ;

select      concat('RUC ' ,[RUC_R]) RUC_C
           ,[RUC]
           ,concat('VALOR ' ,[Nro_Valor]) VALOR_C
           ,[cod_valor]
           ,[codRegimen]
           ,[des_Regimen]
           ,[tama�o]
           ,[des_tama�o]
           ,[a�o] 
--into  [db_proc_procesos1].[n570].[memo60_2f]  ---(402589 row(s) affected)
from [db_proc_procesos1].[n570].[memo60_1f]
order by [RUC_R] asc;

/****************   1   ****************/

select		[RUC_C]
           ,[VALOR_C]           
           ,[codRegimen]
           ,[des_Regimen]
           ,[tama�o]
           ,[des_tama�o]
           ,[a�o]
from [db_proc_procesos1].[n570].[memo60_2f]  
order by 1;


/**************************************************************		PARTE 2		**************************************************************/
--- tabla parametrica de tipo de tributo    ---------  Select * from db_gpgd.dbo.Param_Tributo

select *
from [db_proc_procesos1].[n570].[memo602];
----------------------------------

select top 100 * from db_gpgd.[dbo].[TBL_Valores_Pagados] where fec_pago is null;
select *from [db_proc_procesos1].[n570].[memo602];

/*****************************			Valores pagados en el 2016 y 2017				******************************/
select *-- t2.cod_valor, t1.ruc, t1.per_trib, sum(t1.mto_trib+t1.mto_int+t1.mto_cap) as total_pagado
--into [db_proc_procesos1].[n570].[valor_pagado_2016_2017]
from [db_proc_procesos1].[n570].[memo602] t1
left join db_gpgd.[dbo].[TBL_Valores_Pagados] t2 on t1.cod_valor=t2.cod_valor and t1.ruc=t2.ruc and t1.per_trib=t2.per_trib
where t2.fec_pago between '01/01/2016' and ('31/12/2017')
group by  t2.cod_valor, t1.ruc, t1.per_trib;

---- valores que tienes mas de 1 pago
select t2.cod_valor, count(t2.RUC)--t1.ruc,t1.cod_valor,t1.per_trib, (t1.mto_trib+t1.mto_int+t1.mto_cap) as total_pagado,* 
from [db_proc_procesos1].[n570].[memo602] t1
left join db_gpgd.[dbo].[TBL_Valores_Pagados] t2 on t1.cod_valor=t2.cod_valor and t1.ruc=t2.ruc and t1.per_trib=t2.per_trib
where t2.fec_pago between '01/01/2016' and ('31/12/2017')--;
group by t2.cod_valor
HAVING count(t2.RUC)>1

/*****************************					PROBANDO								**********************************/
select t1.ruc,t1.cod_valor,t1.per_trib, (t1.mto_trib+t1.mto_int+t1.mto_cap) as total_pagado,* 
from [db_proc_procesos1].[n570].[memo602] t1
left join db_gpgd.[dbo].[TBL_Valores_Pagados] t2 on t1.cod_valor=t2.cod_valor and t1.ruc=t2.ruc and t1.per_trib=t2.per_trib
where t1.cod_valor in ('0930020052506');

select * from [db_proc_procesos1].[n570].[valor_pagado_2016_2017] where cod_valor in ('0930020052506');
 
----------------------------------
---- Tabla 3
select * 
from [db_proc_procesos1].[n570].[memo602] t1
left join (select * from db_gpgd.dbo.TBR_Saldos_Valores_Pendientes where mes='12' and a�o='2017') t2 on t1.cod_valor=t2.cod_valor
left join db_gpgd.dbo.Param_Tipo_Doc t3 on t1.cod_doc=t3.cod_doc
left join db_gpgd.dbo.Param_Tributo t4 on t1.cod_trib=t4.cod_trib

--- tabla 4
--  drop table [db_proc_procesos1].[n570].[memo6022];
select *-- t1.cod_trib,t4.descripcion,t1.ruc,t1.cod_valor,t2.mto_trib as Imp_Insoluto, (t2.mto_int+t2.mto_cap) as Int_multaE,
 --(t2.mto_trib+t2.mto_int+t2.mto_cap) as Monto_Total_MultaE, t5.total_pagado
--into [db_proc_procesos1].[n570].[memo6022]
from [db_proc_procesos1].[n570].[memo602] t1
left join (select * from db_gpgd.dbo.TBR_Saldos_Valores_Pendientes where mes='12' and a�o='2017') t2 on t1.cod_valor=t2.cod_valor
left join db_gpgd.dbo.Param_Tipo_Doc t3 on t1.cod_doc=t3.cod_doc
left join db_gpgd.dbo.Param_Tributo t4 on t1.cod_trib=t4.cod_trib
left join [db_proc_procesos1].[n570].[valor_pagado_2016_2017] t5 on t5.ruc=t1.ruc and t1.cod_valor=t5.cod_valor and t1.per_trib=t5.per_trib
--(402589 row(s) affected)

select * 
from [db_proc_procesos1].[n570].[memo6022]; 

select t1.cod_trib, count(t1.RUC) Total_RUC, count(t1.cod_valor) Cantidad_Valores, sum(t1.imp_insoluto) as Importe_Insoluto,
sum(t1.int_multaE) as Interes_multasE, sum(monto_total_MultaE) as Monto_Total_MultaE, sum(t1.total_pagado)as Monto_Pagado_CierreA
from [db_proc_procesos1].[n570].[memo6022] t1 
group by t1.cod_trib





-- tabla5
Select * from [db_proc_procesos1].[n570].[memo602] t1
inner join [db_Gpgd].[dbo].[gpgd_exptes_impug_presentados] t2 on t1.ruc=t2.ruc and t1.cod_valor=t2.num_doc_ri;
--03400 reclamados
--03500 apelados 


select * from [db_Gpgd].[dbo].[gpgd_exptes_impug_presentados];

SELECT *
  FROM [db_Gpgd].[dbo].[Param_Tipo_EXP]








--- tabla parametrica de tipo de tributo
Select * from db_gpgd.dbo.Param_Tributo

--- tabla parametrica de categorias 
Select * from db_gpgd.dbo.Param_Categorias

--- tabla parametrica de regimen
select * from db_data_wh.padron.TB_SUBREGIMEN;

select * from db_analisis.padron.dim_RegimenContri;

select * from db_gpgd.dbo.Param_Etapa


update a
set codRegimen=id_subtipregim
from [db_proc_procesos1].[n570].[memo601] a, db_analisis.padron.dim_Contribuyente b
where a.ruc=b.num_ruc
---(405149 row(s) affected)
--- asignando descripcion de tipo de regimenes

select t1.codRegimen,t1. DesRegimen, * from [db_proc_procesos1].[n570].[memo601] t1
left join db_gpgd.dbo.Param_Tipo_Doc t2 on t2.cod_doc=t1.codRegimen;

update t1.codRegimen,t1. DesRegimen, * from [db_proc_procesos1].[n570].[memo601] t1
left join db_gpgd.dbo.Param_Tipo_Doc t2 on t2.cod_doc=t1.codRegimen;



select codRegimen,* 
from [db_proc_procesos1].[n570].[memo601];