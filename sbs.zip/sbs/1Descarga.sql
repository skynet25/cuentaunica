USE [db_proc]
GO

/****** Object:  StoredProcedure [dbo].[SP_TBL_INCT_NOTARIO_DESCARGA]    Script Date: 07/12/2018 11:48:29 a.m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_TBL_INCT_NOTARIO_DESCARGA]
@ANIO VARCHAR(4)
AS 
BEGIN

	DECLARE @SQL1 VARCHAR(8000)
	DECLARE @tabla1 varchar(200)
	DECLARE @tabla2 varchar(200)
	DECLARE @tabla3 varchar(200)
	DECLARE @tabla4 varchar(200)
	DECLARE @tabla5 varchar(200)
	DECLARE @tabla6 varchar(200)
	DECLARE @tabla7 varchar(200)
	DECLARE @tabla8 varchar(200)
	DECLARE @tabla9 varchar(200)
	DECLARE @tabla10 varchar(200)
	DECLARE @tabla11 varchar(200)
	DECLARE @tabla12 varchar(200)
	DECLARE @tabla13 varchar(200)
	DECLARE @tabla14 varchar(200)
	DECLARE @tabla15 varchar(200)
	DECLARE @tabla16 varchar(200)


	SET @tabla1	= 'TEMP_NOTARIOS_t2102actjur_'+@ANIO
	SET @tabla2 = 'TEMP_NOTARIOS_t2106bienact_'+@ANIO
	SET @tabla3 = 'TEMP_NOTARIOS_t2113otoxbien_'+@ANIO
	SET @tabla4 = 'TEMP_NOTARIOS_t2131regoto_'+@ANIO
	SET @tabla5 = 'TEMP_NOTARIOS_t3055presentainf_'+@ANIO
	SET @tabla6 = 'TEMP_NOTARIOS_t2310escritura_'+@ANIO
	SET @tabla7 = 'TEMP_NOTARIOS_t2486libros_'+@ANIO
	
	SET @tabla8 = 'TEMP_NOTARIOS_t3055presentainf_Fech_Max_'+@ANIO
	SET @tabla9 = 'TEMP_NOTARIOS_t3055presentainf_Horas_Max_'+@ANIO
	SET @tabla10 = 'TEMP_NOTARIOS_t3055presentainf_Ultima_Cabecera_'+@ANIO
	
	SET @tabla11 = 'TEMP_NOTARIOS_t2102actjur_CRUCE_t3055presentainf_'+@ANIO
	SET @tabla12 = 'TEMP_NOTARIOS_t2102actjur_CRUCE_t2106bienact_'+@ANIO
	SET @tabla13 = 'TEMP_NOTARIOS_t2102actjur_CRUCE_t2131regoto_'+@ANIO
	SET @tabla14 = 'TEMP_NOTARIOS_t2102actjur_CRUCE_t2113otoxbien_'+@ANIO
	
	SET @tabla15 = 'TEMP_NOTARIOS_FINAL_'+@ANIO
	SET @tabla16 = 'TEMP_NOTARIOS_MONTO_UNICO_'+@ANIO
	


	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	PRINT('                                      DESCARGAMOS INFORMACION DE LA BDU                                      '+CHAR(10))
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))


	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla1+CHAR(39)+') DROP TABLE '+@tabla1 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla1+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t2102actjur WHERE num_perescrit = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	PRINT('--> TABLA 1 : SELECT * FROM '+@tabla1+CHAR(10))
	
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla2+CHAR(39)+') DROP TABLE '+@tabla2 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla2+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t2106bienact WHERE num_perescrit = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)	
	EXEC(@SQL1)
	
	PRINT('--> TABLA 2 : SELECT * FROM '+@tabla2+CHAR(10))
	
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla3+CHAR(39)+') DROP TABLE '+@tabla3 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla3+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t2113otoxbien WHERE num_perescrit = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)	
	EXEC(@SQL1)
	
	PRINT('--> TABLA 3 : SELECT * FROM '+@tabla3+CHAR(10))

	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla4+CHAR(39)+') DROP TABLE '+@tabla4 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla4+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t2131regoto WHERE num_perregoto = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)	
	EXEC(@SQL1)
	
	PRINT('--> TABLA 4 : SELECT * FROM '+@tabla4+CHAR(10))

	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla5+CHAR(39)+') DROP TABLE '+@tabla5 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla5+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t3055presentainf WHERE num_periodo = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)	
	EXEC(@SQL1)
	
	PRINT('--> TABLA 5 : SELECT * FROM '+@tabla5+CHAR(10))
	
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla6+CHAR(39)+') DROP TABLE '+@tabla6 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla6+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t2310escritura WHERE num_perescrit = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)	
	EXEC(@SQL1)
	
	PRINT('--> TABLA 6 : SELECT * FROM '+@tabla6+CHAR(10))

	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla7+CHAR(39)+') DROP TABLE '+@tabla7 +' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT * INTO '+@tabla7+' FROM OPENQUERY(bdu,'+CHAR(39)+'SELECT * FROM informix.t2486libros WHERE num_perlib = '+CHAR(39)+CHAR(39)+@ANIO+CHAR(39)+CHAR(39)+' '+CHAR(39)+')  '
	PRINT(@SQL1)	
	EXEC(@SQL1)
	
	PRINT('--> TABLA 7 : SELECT * FROM '+@tabla7+CHAR(10))
	
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	PRINT('                                                PROCESO II                                                   '+CHAR(10))
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	PRINT('[===========================================================================]')
	PRINT('[------> SELECCIONAMOS LA MAXIMA FECHA PRESENTADA DE LA CABECERA <----------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla8+CHAR(39)+') DROP TABLE '+@tabla8+' '
	EXECUTE (@SQL1)

	SET @SQL1= 'SELECT cod_cicdec, max(fec_presenta) AS fec_presenta INTO '+@tabla8+' FROM '+@tabla5+' GROUP BY cod_cicdec '
	PRINT(@SQL1)	
	EXEC(@SQL1)
		
	PRINT('--> TABLA 8 : SELECT * FROM '+@tabla8+CHAR(10))
	
	PRINT('[===========================================================================]')
	PRINT('[------------------------> SE EXTRAE LA ULTIMA HORA <-----------------------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla9+CHAR(39)+') DROP TABLE '+@tabla9+' '
	EXECUTE (@SQL1)

	SET @SQL1= 'select a.cod_cicdec, max(a.hor_presenta) as hora_presenta  into '+@tabla9+' 
				from '+@tabla5+' a, '+@tabla8+' b where a.cod_cicdec=b.cod_cicdec and a.fec_presenta=b.fec_presenta 
				group by a.cod_cicdec
				'
	PRINT(@SQL1)	
	EXEC(@SQL1)
		
	PRINT('--> TABLA 8 : SELECT * FROM '+@tabla9+CHAR(10))
	
	PRINT('[===========================================================================]')
	PRINT('[------------------> SE AGREGA UNA COLUMNA Y ACTUALIZA <--------------------]')
		PRINT('[===========================================================================]')
	
	SET @SQL1= 'ALTER TABLE '+@tabla8+' ADD hora_presenta VARCHAR(255) NULL '
	PRINT(@SQL1)
	EXEC(@SQL1)

	PRINT('--> AGREGO UNA COLUMNA: hora_presenta')
	
	SET @SQL1= 'UPDATE a SET a.hora_presenta = b.hora_presenta FROM '+@tabla8+' a, '+@tabla9+' b WHERE a.cod_cicdec=b.cod_cicdec'
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	PRINT('[===========================================================================]')
	PRINT('[--------------------> FILTRAR LAS ULTIMAS PRESENTADAS <--------------------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla10+CHAR(39)+') DROP TABLE '+@tabla10+' '
	EXECUTE (@SQL1)
	
	SET @SQL1= 'SELECT a.*  INTO '+@tabla10+' FROM '+@tabla5+' a, '+@tabla8+' b
				WHERE a.cod_cicdec = b.cod_cicdec and a.fec_presenta = b.fec_presenta and a.hor_presenta collate SQL_Latin1_General_CP1_CI_AS = b.hora_presenta
				'
	PRINT(@SQL1)
	EXEC(@SQL1)

	PRINT('--> TABLA 10 : SELECT * FROM '+@tabla10+CHAR(10))
	
	
	
	
	PRINT('[===========================================================================]')
	PRINT('[-------------------------> CRUCE CON ACTO JURIDICO <-----------------------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla11+CHAR(39)+') DROP TABLE '+@tabla11+' '
	EXECUTE (@SQL1)
	
	SET @SQL1= 'SELECT actjur.* INTO '+@tabla11+' FROM '+@tabla10+' presinf,  '+@tabla1+' actjur 
				WHERE 
					presinf.cod_cicdec = actjur.cod_cicnotari AND 
					presinf.num_ordpres = actjur.num_ordnot AND 
					presinf.num_periodo = actjur.num_perescrit
				'
	PRINT(@SQL1)
	EXEC(@SQL1)

	PRINT('--> TABLA 11 : SELECT * FROM '+@tabla11+CHAR(10))


	PRINT('[===========================================================================]')
	PRINT('[----------------------------> CRUCE CON BIEN ACTO <------------------------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla12+CHAR(39)+') DROP TABLE '+@tabla12+' '
	EXECUTE (@SQL1)
	
	SET @SQL1= 'SELECT bienact.* INTO '+@tabla12+' FROM '+@tabla10+' presinf, '+@tabla2+' bienact 
				WHERE presinf.cod_cicdec = bienact.cod_cicnotari AND 
				      presinf.num_periodo = bienact.num_perescrit AND 
				      presinf.num_ordpres = bienact.num_ordnot
				'
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	PRINT('--> TABLA 12 : SELECT * FROM '+@tabla12+CHAR(10))
	

	PRINT('[===========================================================================]')
	PRINT('[------------------------------> CRUCE CON REGOTO <-------------------------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla13+CHAR(39)+') DROP TABLE '+@tabla13+' '
	EXECUTE (@SQL1)
	
	SET @SQL1= 'SELECT regoto.* INTO '+@tabla13+' FROM '+@tabla10+' presinf, '+@tabla4+' regoto 
				WHERE presinf.cod_cicdec = regoto.cod_cicnotari AND 
				      presinf.num_periodo = regoto.num_perregoto  AND 
				      presinf.num_ordpres = regoto.num_ordnot
				'
	PRINT(@SQL1)
	EXEC(@SQL1)

	PRINT('--> TABLA 13 : SELECT * FROM '+@tabla13+CHAR(10))
	
	
	PRINT('[===========================================================================]')
	PRINT('[------------------------------> CRUCE CON OTOXBIEN <-----------------------]')	
	PRINT('[===========================================================================]')
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla14+CHAR(39)+') DROP TABLE '+@tabla14+' '
	EXECUTE (@SQL1)
	
	SET @SQL1= 'SELECT otoxbien.* INTO '+@tabla14+' FROM '+@tabla10+' presinf, '+@tabla3+' otoxbien 
				WHERE presinf.cod_cicdec = otoxbien.cod_cicnotari AND 
				      presinf.num_periodo = otoxbien.num_perescrit AND 
				      presinf.num_ordpres = otoxbien.num_ordnot
				'
	PRINT(@SQL1)
	EXEC(@SQL1)

	PRINT('--> TABLA 14 : SELECT * FROM '+@tabla14+CHAR(10))
	
	/*
	PRINT('[===========================================================================]')
	PRINT('[------------------> ACTUALIZAMOS EL CIC DE t2131regoto <-------------------]')
	PRINT('[===========================================================================]')
	


	SET @SQL1= 'UPDATE a SET a.cod_cicotod = b.cic FROM '+@tabla13+' a, db_padron.dbo.tbl_gpgf_identificados b
				WHERE 
				a.cod_tipdocoto = b.tipo_dcto_declado and 
				a.num_docoto collate SQL_Latin1_General_CP1_CI_AS = b.n_dcto_declado 
				and a.cod_cicotod = 0
				'
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	SET @SQL1= 'UPDATE a SET a.cod_cicotod = b.cic,a.cod_tipdocoto=1 FROM '+@tabla13+' a, db_padron.dbo.tbl_gpgf_identificados b
				WHERE 
				a.cod_tipdocoto = 0 and 
				len(a.num_docoto)=8 and
				a.num_docoto collate SQL_Latin1_General_CP1_CI_AS = b.n_dcto_declado  and
				b.tipo_dcto_declado=1 and
				left(a.num_docoto,4)<>'''+@ANIO+''''
			
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	SET @SQL1= 'UPDATE a SET a.cod_cicotod = b.cic,a.cod_tipdocoto=6 FROM '+@tabla13+' a, db_padron.dbo.tbl_gpgf_identificados b
				WHERE 
				a.cod_tipdocoto = 0 and 
				len(a.num_docoto)=11 and
				a.num_docoto collate SQL_Latin1_General_CP1_CI_AS = b.n_dcto_declado  and
				b.tipo_dcto_declado=6 
				--and left(a.num_docoto,4)<>'''+@ANIO+''''
			
	PRINT(@SQL1)
	EXEC(@SQL1)
	*/
	
	
	/*
	
	PRINT('[===========================================================================]')
	PRINT('[------------------------> GENERAMOS LA TABLA NOTARIOS <--------------------]')	PRINT('[===========================================================================]')
	



	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla15+CHAR(39)+') DROP TABLE '+@tabla15+' '
	EXECUTE (@SQL1)
	
	SET @SQL1= '
	SELECT   t21.cod_escritura, t21.fec_numesc, t21.ind_tipopenot, 
			 t21.num_actjur, t21.cod_tipactjur, t21.cod_moneda, 
			 t21.des_otactjur, t21.mto_actjur, t21.fec_inipla, 
			 t21.fec_finpla, t21.num_bienes, t21.cod_banco, 
			 t21.cod_medpag, t21.fec_minuta, t21.ind_pago, 
			 t21.cod_monedapag, t21.mto_pagado as mto_pagado_aj, t21.fec_emision, 
			 t21.num_documento, t211.num_ordbien, t211.cod_pais, 
			 t211.cod_ubigeo as cod_ubigeo_bns, t211.cod_bienn, t211.des_otbien, 
			 t211.ind_tipmat, t211.des_tipmat, t211.ind_tbien, 
			 t211.ind_oribien, t211.num_serie, t211.fec_adquis, 
			 t212.cod_tipdocoto, t212.num_docoto, t212.num_secotg, 
			 t212.cod_otorgante, t212.num_porcoto, t212.ind_tercera, 
			 t212.ind_bien, t212.num_ordenf1662, t212.mto_pagado as mto_pagado_oxb, 
			 t213.ind_tipper, t213.cod_ubigeo as cod_ubigeo_oto, t213.des_nomoto, 
			 t213.cod_cicotod, t213.cod_valregn, t30.cod_cicdec, 
			 t30.num_periodo, t30.cod_formul, t30.num_ordpres, 
			 t30.cod_depen, t30.fec_presenta, t30.hor_presenta, 
			 t30.cod_tipdocdec, t30.num_docdec, t30.ind_estado_pdt, 
			 t30.ind_estado_carga, t30.ind_ultima, t30.ind_detalle ,
			 case when t21.num_bienes=''1'' then ''1'' else ''0'' end as Ind_Bienes,
			 convert(varchar(1),''1'') as Ind_Estado
	INTO     '+@tabla15+'
	FROM     '+@tabla11+' t21, 
			 '+@tabla12+' t211, 
			 '+@tabla14+' t212, 
			 '+@tabla13+' t213, 
			 '+@tabla10+' t30 
	WHERE    LTRIM(RTRIM(t21.num_perescrit)) = LTRIM(RTRIM(t211.num_perescrit))
	AND      LTRIM(RTRIM(t21.cod_cicnotari)) = LTRIM(RTRIM(t211.cod_cicnotari)) 
	AND      LTRIM(RTRIM(t21.num_ordnot)) = LTRIM(RTRIM(t211.num_ordnot)) 
	AND      LTRIM(RTRIM(t21.cod_escritura)) = LTRIM(RTRIM(t211.cod_escritura)) 
	AND      LTRIM(RTRIM(t21.fec_numesc)) = LTRIM(RTRIM(t211.fec_numesc)) 
	AND      LTRIM(RTRIM(t21.ind_tipopenot)) = LTRIM(RTRIM(t211.ind_tipopenot)) 
	AND      LTRIM(RTRIM(t21.num_actjur)) = LTRIM(RTRIM(t211.num_actjur)) 
	AND      LTRIM(RTRIM(t211.cod_cicnotari))  = LTRIM(RTRIM(t212.cod_cicnotari)) 
	AND      LTRIM(RTRIM(t211.num_perescrit)) = LTRIM(RTRIM(t212.num_perescrit)) 
	AND      LTRIM(RTRIM(t211.num_ordnot)) = LTRIM(RTRIM(t212.num_ordnot)) 
	AND      LTRIM(RTRIM(t211.cod_escritura)) = LTRIM(RTRIM(t212.cod_escritura)) 
	AND      LTRIM(RTRIM(t211.fec_numesc)) = LTRIM(RTRIM(t212.fec_numesc)) 
	AND      LTRIM(RTRIM(t211.ind_tipopenot)) = LTRIM(RTRIM(t212.ind_tipopenot)) 
	AND      LTRIM(RTRIM(t211.num_actjur)) = LTRIM(RTRIM(t212.num_actjur)) 
	AND      LTRIM(RTRIM(t211.num_ordbien)) = LTRIM(RTRIM(t212.num_ordbien)) 
	AND      LTRIM(RTRIM(t212.cod_cicnotari)) = LTRIM(RTRIM(t213.cod_cicnotari)) 
	AND      LTRIM(RTRIM(t212.num_perescrit)) = LTRIM(RTRIM(t213.num_perregoto)) 
	AND      LTRIM(RTRIM(t212.cod_tipdocoto)) = LTRIM(RTRIM(t213.cod_tipdocoto)) 
	AND      LTRIM(RTRIM(t212.num_docoto)) = LTRIM(RTRIM(t213.num_docoto)) 
	AND      LTRIM(RTRIM(t212.num_ordnot)) = LTRIM(RTRIM(t213.num_ordnot)) 
	AND      LTRIM(RTRIM(t30.cod_cicdec)) = LTRIM(RTRIM(t21.cod_cicnotari)) 
	AND      LTRIM(RTRIM(t30.num_periodo)) = LTRIM(RTRIM(t21.num_perescrit)) 
	AND      LTRIM(RTRIM(t30.num_ordpres)) = LTRIM(RTRIM(t21.num_ordnot))	
			 
	'
	PRINT(@SQL1)
	EXEC(@SQL1)

	PRINT('--> TABLA 15 : SELECT * FROM '+@tabla15+CHAR(10))

*/

	
	/*
	PRINT('[===========================================================================]')
	PRINT('[----------------> GENERAMOS LA TABLA NOTARIOS_MONTO_UNICO <----------------]')	PRINT('[===========================================================================]')
	
	
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '+CHAR(39)+@tabla16+CHAR(39)+') DROP TABLE '+@tabla16+' '
	EXECUTE (@SQL1)
	
	
	SET @SQL1= '
	
	SELECT 
	cod_depen,cod_cicdec,num_docdec,num_ordpres,fec_presenta, ind_tipopenot,cod_tipactjur,cod_moneda,fec_numesc,cod_escritura,num_actjur,
	cod_cicotod,cod_tipdocoto,num_docoto,cod_otorgante,
	MIN(CONVERT(DECIMAL(20,2),ISNULL(num_porcoto,'+CHAR(39)+'0'+CHAR(39)+'))) AS num_porcoto,
	MIN(CONVERT(DECIMAL(20,2),ISNULL(mto_actjur,'+CHAR(39)+'0'+CHAR(39)+'))) AS mto_actjur, 
	MIN(CONVERT(INT,ISNULL(num_bienes,'+CHAR(39)+'0'+CHAR(39)+'))) AS num_bienes,
	convert(varchar(1),''1'') as Ind_Estado 
	INTO '+@tabla16+'
	FROM '+@tabla15+'
	GROUP BY cod_depen,cod_cicdec,num_docdec,num_ordpres,fec_presenta,ind_tipopenot,cod_tipactjur,cod_moneda,fec_numesc,cod_escritura,num_actjur,
	cod_cicotod,cod_tipdocoto,num_docoto,cod_otorgante

	'
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	PRINT('--> TABLA 16 : SELECT * FROM '+@tabla16+CHAR(10))
	
	

	PRINT('=============================================================================================================='+CHAR(10))
	PRINT('  EN CASO DEL TIPO DE ACTO JURIDICO PERMUTA :SE DUPLICARA LOS MONTOS DE NOTARIOS EN LA TABLA DE MONTOS UNICOS'+CHAR(10))
	PRINT('=============================================================================================================='+CHAR(10))
	
	PRINT('=============================================================================================================='+CHAR(10))
	PRINT('                    NO SE POSEE UN CAMPO DISTINTIVO DE DISCRIMINACION DEL INTERCAMBIO                          '+CHAR(10))
	PRINT('=============================================================================================================='+CHAR(10))
	
	*/
		/*
	
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	PRINT('                                        ELIMINAMOS LA TABLAS TEMPORALES                                      '+CHAR(10))
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	
	SET @SQL1='
	DROP TABLE '+@tabla1+';
	DROP TABLE '+@tabla2+';
	DROP TABLE '+@tabla3+';
	DROP TABLE '+@tabla4+';
	DROP TABLE '+@tabla5+';
	DROP TABLE '+@tabla6+';
	DROP TABLE '+@tabla7+';
	DROP TABLE '+@tabla8+';
	DROP TABLE '+@tabla9+';
	DROP TABLE '+@tabla10+';
	DROP TABLE '+@tabla11+';
	DROP TABLE '+@tabla12+';
	DROP TABLE '+@tabla13+';
	DROP TABLE '+@tabla14+';
	'
	PRINT(@SQL1)
	EXEC(@SQL1)
	*/
	
	/*
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	PRINT('                                                RESULTADO FINAL                                              '+CHAR(10))
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	

	PRINT('--> TABLA NOTARIOS : SELECT * FROM '+@tabla15+CHAR(10))
	PRINT('--> TABLA NORTARIOS MONTO UNICO : SELECT * FROM '+@tabla16+CHAR(10))
	
	SET @SQL1='DELETE FROM DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_'+@ANIO+''
	PRINT(@SQL1)
	
	SET @SQL1='DELETE FROM DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO'
	PRINT(@SQL1)
	
	SET @SQL1='	
	INSERT INTO DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_'+@ANIO+' 
	SELECT * FROM '+@tabla15+'
	'
	PRINT(@SQL1)
	
	SET @SQL1='
	INSERT INTO DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO
	SELECT * FROM '+@tabla16+'
	'
	PRINT(@SQL1)
	
	PRINT('[-----------------------------------------------------------------------------------------------------------]'+CHAR(10))
	*/
END

	


GO

