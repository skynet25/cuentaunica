USE [db_proc]
GO

/****** Object:  StoredProcedure [dbo].[SP_TBL_INCT_NOTARIO_CONSISTENCIA]    Script Date: 07/12/2018 11:49:14 a.m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SP_TBL_INCT_NOTARIO_CONSISTENCIA]
@ANIO VARCHAR(4)
AS 
BEGIN

	DECLARE @SQL1 VARCHAR(8000)
	DECLARE @tabla1 varchar(200)
	DECLARE @tabla2 varchar(200)
	DECLARE @tabla3 varchar(200)
	DECLARE @tabla4 varchar(200)
	DECLARE @tabla5 varchar(200)
	DECLARE @tabla10 varchar(200)
	DECLARE @tabla11 varchar(200)
	DECLARE @tabla12 varchar(200)
	DECLARE @tabla13 varchar(200)
	DECLARE @tabla14 varchar(200)
	DECLARE @TABLA_IDENTIFICADO varchar(200)
	DECLARE @TABLA_PADRON varchar(200)
	DECLARE @TABLA_INCONSISTENCIA_NRODOC varchar(200)

	DECLARE @TABLA_INCONSISTENCIA_ITF_PRE varchar(200)
	DECLARE @TABLA_INCONSISTENCIA_ITF varchar(200)
	
	DECLARE @TABLA_INCONSISTENCIA_PRE varchar(200)
	DECLARE @TABLA_INCONSISTENCIA_UNICAS varchar(200)
	DECLARE @TABLA_INCONSISTENCIA varchar(200)
	
	
	DECLARE @CabNotarios varchar(200)
	DECLARE @ActoJuridico varchar(200)
	DECLARE @ANIO_ANT VARCHAR(4)
	DECLARE @TABLA_INCONSISTENCIA_NOTARIO varchar(200)
	DECLARE @TABLA_INCONSISTENCIA_MONTO_S VARCHAR(200)
	DECLARE @TABLA_INCONSISTENCIA_MONTO_D VARCHAR(200)
		
	SET @ANIO_ANT=CONVERT(VARCHAR(4),CONVERT(INT,@ANIO-1))


	
	SET @tabla1 = 'TEMP_NOTARIOS_FINAL_'+@ANIO
	SET @tabla10 = 'TEMP_NOTARIOS_MONTO_UNICO_'+@ANIO
	SET @tabla11 = 'db_procesado.dbo.TBL_ITF_'+@ANIO
	SET @tabla12 = 'DB_PROCESADO.DBO.TBL_INCT_TIPO_CAMBIO_ANUAL'
	SET @tabla13 = 'db_procesado.dbo.TBL_INCT_PERCO_ITF '
	SET @tabla14 = 'TEMP_NOTARIOS_MONTO_UNICO_'+@ANIO_ANT
	
	SET @tabla2 = 'TEMP_NOTARIOS_CONSISTENCIAR_'+@ANIO
	SET @tabla3 = 'TEMP_NOTARIOS_INCON_01_'+@ANIO
	SET @tabla4 = 'TEMP_NOTARIOS_INCON_02_'+@ANIO
	SET @tabla5 = 'TEMP_NOTARIOS_INCON_03_'+@ANIO
	
	
	SET @TABLA_INCONSISTENCIA_NRODOC='NOT_INCON_NRODOC_'+@ANIO	
	
	SET @TABLA_INCONSISTENCIA_ITF_PRE='NOTARIOS_INCON_ITF_PRE_'+@ANIO
	SET @TABLA_INCONSISTENCIA_ITF='NOT_INCON_ITF_'+@ANIO	
	SET @TABLA_INCONSISTENCIA_NOTARIO='NOT_INCON_NOTARIO_'+@ANIO
	SET @CabNotarios='TEMP_NOTARIOS_t3055presentainf_Ultima_Cabecera_'+@ANIO
	SET @ActoJuridico='TEMP_NOTARIOS_t2102actjur_CRUCE_t3055presentainf_'+@ANIO
	
	SET @TABLA_INCONSISTENCIA_MONTO_S='NOT_INCON_MONT_SOL_'+@ANIO	SET @TABLA_INCONSISTENCIA_MONTO_D='NOT_INCON_MONT_DOL_'+@ANIO	
	
	SET @TABLA_INCONSISTENCIA_PRE ='NOTARIOS_INCON_PRE_'+@ANIO
	SET @TABLA_INCONSISTENCIA_UNICAS='NOTARIOS_INCON_UNICAS_'+@ANIO
	
	SET @TABLA_INCONSISTENCIA ='NOTARIOS_INCONSISTENCIAS'+@ANIO  
	
		
	SET @TABLA_PADRON	=(SELECT NOM_BASE+'.'+NOM_ESQUEMA+'.'+NOM_TABLA FROM DB_PROC.DBO.P006_PROCESO_PARAMETRO WHERE NOM_NEMO='PADRON') 
	SET @TABLA_IDENTIFICADO=(SELECT NOM_BASE+'.'+NOM_ESQUEMA+'.'+NOM_TABLA FROM DB_PROC.DBO.P006_PROCESO_PARAMETRO WHERE NOM_NEMO='IDENTIFICADO') 
	


	PRINT('================================================================================================')
	PRINT('-------------------------------> GENERAMOS LA TABLA DE NOTARIOS A CONSISTENCIAR <---------------')
	PRINT('================================================================================================')
	
			
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@tabla2+''') DROP TABLE '+@tabla2
	EXECUTE (@SQL1)
	
				
	SET @SQL1= '
			Select t30.cod_escritura, t30.fec_numesc, t30.ind_tipopenot, 
			 t30.num_actjur, t30.cod_tipactjur, t30.cod_moneda, 
			 t30.des_otactjur, t30.mto_actjur, t30.fec_inipla, 
			 t30.fec_finpla, t30.num_bienes, t30.cod_banco, 
			 t30.cod_medpag, t30.fec_minuta, t30.ind_pago, 
			 t30.cod_monedapag, t30.mto_pagado_aj, t30.fec_emision, 
			 t30.num_documento	,
			 t30.cod_tipdocoto, t30.num_docoto, t30.num_secotg, 
			 t30.cod_otorgante, t30.num_porcoto, t30.ind_tercera, 
			 t30.ind_bien, t30.num_ordenf1662, t30.mto_pagado_oxb, 
			 t30.ind_tipper, t30.cod_ubigeo_oto, t30.des_nomoto, 
			 t30.cod_cicotod, t30.cod_valregn, t30.cod_cicdec, 
			 t30.num_periodo, t30.cod_formul, t30.num_ordpres, 
			 t30.cod_depen, t30.fec_presenta, t30.hor_presenta, 
			 t30.cod_tipdocdec, t30.num_docdec, t30.ind_estado_pdt, 
			 t30.ind_estado_carga, t30.ind_ultima, t30.ind_detalle 
			
	INTO     '+@tabla2+'
	FROM      '+@tabla1+' t30 
	group by  t30.cod_escritura, t30.fec_numesc, t30.ind_tipopenot, 
			 t30.num_actjur, t30.cod_tipactjur, t30.cod_moneda, 
			 t30.des_otactjur, t30.mto_actjur, t30.fec_inipla, 
			 t30.fec_finpla, t30.num_bienes, t30.cod_banco, 
			 t30.cod_medpag, t30.fec_minuta, t30.ind_pago, 
			 t30.cod_monedapag, t30.mto_pagado_aj, t30.fec_emision, 
			 t30.num_documento	,
			 t30.cod_tipdocoto, t30.num_docoto, t30.num_secotg, 
			 t30.cod_otorgante, t30.num_porcoto, t30.ind_tercera, 
			 t30.ind_bien, t30.num_ordenf1662, t30.mto_pagado_oxb, 
			 t30.ind_tipper, t30.cod_ubigeo_oto, t30.des_nomoto, 
			 t30.cod_cicotod, t30.cod_valregn, t30.cod_cicdec, 
			 t30.num_periodo, t30.cod_formul, t30.num_ordpres, 
			 t30.cod_depen, t30.fec_presenta, t30.hor_presenta, 
			 t30.cod_tipdocdec, t30.num_docdec, t30.ind_estado_pdt, 
			 t30.ind_estado_carga, t30.ind_ultima, t30.ind_detalle 
		 
	'
		EXEC(@SQL1)

	PRINT('--> GENERANDO LA TABLA BASE CON LA QUE SE SACARA LAS INCONSISTENCIAS DE MONTOS---->')
	PRINT('--> TABLA 2 : SELECT * FROM '+@tabla2+CHAR(10))
	
	
	PRINT('==============================================================================================')
	PRINT('-------------> GENERAMOS LAS TABLA SOLO NUMERO DE DOCUMENTO OTOR. NUMERICO <----- ------------')
	PRINT('==============================================================================================')
	
	
	
	SET @SQL1= '
	
	DELETE FROM '+@tabla2+' WHERE ISNUMERIC(num_docoto)=''0''
	'
		EXEC(@SQL1)
	
	
	
	SET @SQL1= '
	
	DELETE FROM '+@tabla2+'
	WHERE
	(charindex('' '', LTRIM(RTRIM(num_docoto))) > 0 or 					-- Valida que no existan espacios en blanco
   	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''%.%'' or 			-- Valida el caracter de posicion 01
   	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''[^0123456789.]%'' or 			-- Valida el caracter de posicion 01
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''[^0123456789.]%'' or 			-- Valida el caracter de posicion 01
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_[^0123456789.]%'' or 			-- Valida el caracter de posicion 02
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''__[^0123456789.]%'' or 			-- Valida el caracter de posicion 03
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''___[^0123456789.]%'' or 		-- Valida el caracter de posicion 04
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''____[^0123456789.]%'' or 		-- Valida el caracter de posicion 05
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_____[^0123456789.]%'' or 		-- Valida el caracter de posicion 06
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''______[^0123456789.]%'' or 		-- Valida el caracter de posicion 06
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_______[^0123456789.]%'' or 		-- Valida el caracter de posicion 07
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''________[^0123456789.]%'' or 		-- Valida el caracter de posicion 08
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_________[^0123456789.]%'' or 		-- Valida el caracter de posicion 09
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''__________[^0123456789.]%'' or 		-- Valida el caracter de posicion 10
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''___________[^0123456789.]%'' or 	-- Valida el caracter de posicion 11
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''____________[^0123456789.]%'' or 	-- Valida el caracter de posicion 12
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_____________[^0123456789.]%'' or 	-- Valida el caracter de posicion 13
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''______________[^0123456789.]%'' or 	-- Valida el caracter de posicion 14
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_______________[^0123456789.]%'' or 	-- Valida el caracter de posicion 15
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''________________[^0123456789.]%'' or 	-- Valida el caracter de posicion 16
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''_________________[^0123456789.]%'' or 	-- Valida el caracter de posicion 17
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''__________________[^0123456789.]%'' or 	-- Valida el caracter de posicion 18
	ltrim(rtrim(isnull(num_docoto, ''0''))) like ''___________________[^0123456789.]%'' 
	)
	'	
		EXEC(@SQL1)
	
	PRINT('==============================================================================================')
	PRINT('------> PROCEDEMOS A AGREGAR Y ACTUALIZAR EL DNI DEL OTOR. APARTIR DEL DNI    <------------')
	PRINT('==============================================================================================')	
	
	
	SET @SQL1= '
	 ALTER TABLE '+@tabla2+' ADD  DNI_OTORGANTE Varchar(15)
	 '
	  	 EXEC(@SQL1)

	SET @SQL1= 'UPDATE a  SET a.DNI_OTORGANTE = b.N_DCTO_DECLADO 
				FROM '+@tabla2+' a, '+@TABLA_IDENTIFICADO+' b
				WHERE 
				a.cod_cicotod = b.CIC and 
				B.TIPO_DCTO_DECLADO=1
				'
		EXEC(@SQL1)
	
	PRINT('===================================================================================================')
	PRINT('-------------> PROCEDEMOS A GENERAR LAS INCONSISTENCIAS POR NRO DE DOCUMENTO     <------------------')
	PRINT('===================================================================================================')	
	
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@tabla3+''') DROP TABLE '+@tabla3
	EXECUTE (@SQL1)
	
	
	SET @SQL1= '
	
	select 
	cod_depen, cod_cicdec, num_periodo, cod_formul,  num_ordpres,  fec_presenta,  hor_presenta, num_docdec, cod_escritura, fec_numesc, ind_tipopenot, num_actjur, 
	cod_tipactjur, cod_moneda,  cod_tipdocoto, num_docoto,ind_tipper,DNI_OTORGANTE,  
	cod_otorgante, num_porcoto, mto_actjur ,FLOOR(mto_actjur)- CONVERT(DECIMAL(35,0),num_docoto)   as Mto_resta,
	(FLOOR(mto_actjur)/ CONVERT(DECIMAL(35,0),num_docoto)) AS DIVISION
	into '+@tabla3+'
	from '+@tabla2+'
	WHERE CONVERT(DECIMAL(35,0),num_docoto) >0 AND
	((FLOOR(mto_actjur)/ CONVERT(DECIMAL(35,0),num_docoto))  BETWEEN ''0.99997'' AND ''1'') OR (FLOOR(mto_actjur)=CONVERT(DECIMAL(35,0),DNI_OTORGANTE))
	'
		EXEC(@SQL1)

		
	PRINT('--> TABLA 3 : SELECT * FROM '+@tabla3+CHAR(10))
	
		
	PRINT('===================================================================================================')
	PRINT('--------> PROCEDEMOS A DAR ESTRUCTURA SOLICITADA - INCONSISTENCIAPOR NRO DE DOCUMENTO <------------')
	PRINT('===================================================================================================')	
		
	
	SET @SQL1= '
	 ALTER TABLE '+@tabla3+' ADD  RAZON Varchar(150)
	 '
	  	 EXEC(@SQL1)

	SET @SQL1= 'UPDATE a  SET a.razon = b.Nombre 
				FROM '+@tabla3+' a, '+@TABLA_PADRON+' b
				WHERE 
				a.num_docdec = b.ruc collate Modern_Spanish_CI_AS
				'
		EXEC(@SQL1)
	
	PRINT('--> AGREGANDO RAZON A LA TABLA DE INCONSISTENCIAS  POR NRO DOCUMENTO : SELECT * FROM '+@TABLA3+CHAR(10))

	PRINT('================================================================================================')
	PRINT('------------------------> FORMATEAR LA ESTRUCTURA A REMITIR INC-NRODOC <----- ------------------')
	PRINT('===============================================================================================')	
	
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA_NRODOC+''') 
	DROP TABLE '+@TABLA_INCONSISTENCIA_NRODOC
	EXECUTE (@SQL1)
	
		
	SET @SQL1= '
	
	SELECT cod_depen,num_docdec,razon,num_periodo,cod_formul,num_ordpres,fec_presenta,cod_escritura,fec_numesc,
	CASE WHEN ind_tipopenot=''1'' THEN ''ESCRITURA'' ELSE CASE WHEN ind_tipopenot=''2'' THEN ''ACTA NOTARIAL'' ELSE CASE WHEN ind_tipopenot=''3'' 
	THEN ''FORMULARIO REGISTRAL'' 	ELSE CASE WHEN ind_tipopenot=''4''  THEN ''FORMULARIO DE INSCRIPCIÓN'' ELSE '''' END  END END  END AS Nom_ind_tipopenot,
	num_actjur,dbo.f_Nom_cod_tipactjur(cod_tipactjur) AS Nom_cod_tipactjur,
	CASE WHEN COD_MONEDA=''PEN'' THEN ''SOLES'' ELSE CASE WHEN COD_MONEDA=''USD'' THEN ''DOLARES'' ELSE ''-'' END  END AS MONEDA,
	cod_tipdocoto,	num_docoto,	DBO.f_Nom_Cod_Otorgante (cod_otorgante) AS Nom_cod_otorgante,num_porcoto,mto_actjur,cod_otorgante,ind_tipopenot,COD_MONEDA,cod_tipactjur,cod_cicdec
	INTO '+@TABLA_INCONSISTENCIA_NRODOC+'
	FROM  '+@TABLA3+'
	
	'
		EXEC(@SQL1)
	
	PRINT('--> NOTARIOS INCONISTENCIA POR NRO DOCUMENTO: SELECT * FROM '+@TABLA_INCONSISTENCIA_NRODOC+CHAR(10))

	

		
/*
	PRINT('===================================================================================================================================')
	PRINT('----------------> INCONSISTENCIA EN LA DECLARACION DEL NOTARIO MONTOS GRANDES QUE TERMINAN EN 000 CEROS <-------------------------')
	PRINT('===================================================================================================================================')	
	
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA_NOTARIO+''') 
	DROP TABLE '+@TABLA_INCONSISTENCIA_NOTARIO
	EXECUTE (@SQL1)
				
	SET @SQL1= '
	
	select cod_cicdec,num_docdec as num_docdec into '+@TABLA_INCONSISTENCIA_NOTARIO+'
	from '+@CabNotarios+'
	group by cod_cicdec,num_docdec'
	
	EXEC(@SQL1)
	
	SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  IndIncon_NroDoc Varchar(1)
	 '
 	 EXEC(@SQL1)
 	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  NroActJur  int
	 '
 	 EXEC(@SQL1)
 	 
	SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  NroRegErrados int
	 '
 	 EXEC(@SQL1)
 	 
 				
	SET @SQL1='
		
				UPDATE  '+@TABLA_INCONSISTENCIA_NOTARIO+'
				SET IndIncon_NroDoc = ''1''
				FROM '+@TABLA_INCONSISTENCIA_NOTARIO+' a, '+@TABLA_INCONSISTENCIA_NRODOC+' b
				WHERE 
				a.num_docdec=b.num_docdec collate Modern_Spanish_CI_AS	'
	EXEC(@SQL1)
	
	

	SET @SQL1='
				UPDATE  '+@TABLA_INCONSISTENCIA_NOTARIO+'
				SET NroActJur = B.cantidad
				FROM '+@TABLA_INCONSISTENCIA_NOTARIO+' a, 
				
				( select cod_cicnotari AS cod_cicdec,COUNT(*) AS CANTIDAD
				FROM '+@ActoJuridico+' 
				GROUP BY cod_cicnotari
				)  B
				WHERE 
				A.cod_cicdec=B.cod_cicdec 	'
				
		EXEC(@SQL1)
	
	
		
	
	SET @SQL1='
		
				UPDATE  '+@TABLA_INCONSISTENCIA_NOTARIO+'
				SET NroRegErrados = B.CANTIDAD
				FROM '+@TABLA_INCONSISTENCIA_NOTARIO+' a, 
				(SELECT num_docdec,COUNT(*) AS CANTIDAD FROM '+@TABLA_INCONSISTENCIA_NRODOC+' 
				GROUP BY num_docdec				
				) AS B
				WHERE 
				A.num_docdec=B.num_docdec '
	EXEC(@SQL1)
	
	
	*/
	
	/**********AÑO ANTERIOR EN SOLES****/
	
	/*
	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  NroOper_04_'+@ANIO_ANT+'_S  int
	 '
 	 EXEC(@SQL1)
 	 
 	 	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  MtoAdq_04_'+@ANIO_ANT+'_S  DECIMAL(20,2)
	 '
 	 EXEC(@SQL1)
 	 
 	SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  Ratio_'+@ANIO_ANT+'_S  DECIMAL(20,5)
	 '
 	 EXEC(@SQL1)
 	 */
 	 
 	 /**********AÑO ACTUAL EN SOLES**********/
 	 
 	 /*
 	 
 	  SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  NroOper_04_'+@ANIO+'_S  int
	 '
 	 EXEC(@SQL1)
 	 
 	  	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  MtoAdq_04_'+@ANIO+'_S  DECIMAL(20,2)
	 '
 	 EXEC(@SQL1)
 	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  Ratio_'+@ANIO+'_S  DECIMAL(20,5)
	 '
 	 EXEC(@SQL1)
 	 */
 	 
 	 /**************INDICADOR  EN SOLES*********/
 	 /*
 	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  Indicador_S  int
	 '
 	 EXEC(@SQL1)
 	 */
 	 
 	 	 
 	 /**************************TRABAJAMOS DOLARES*****************************/
 	  	 
 	 
	/**********AÑO ANTERIOR EN SOLES****/
	/*
	
	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  NroOper_04_'+@ANIO_ANT+'_D  int
	 '
 	 EXEC(@SQL1)
 	 
 	 	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  MtoAdq_04_'+@ANIO_ANT+'_D  DECIMAL(20,2)
	 '
 	 EXEC(@SQL1)
 	 
 	SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  Ratio_'+@ANIO_ANT+'_D  DECIMAL(20,5)
	 '
 	 EXEC(@SQL1)
 	 */
 	 
 	 /**********AÑO ACTUAL EN SOLES**********/
 	 
 	 /*
 	  SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  NroOper_04_'+@ANIO+'_D  int
	 '
 	 EXEC(@SQL1)
 	 
 	  	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  MtoAdq_04_'+@ANIO+'_D  DECIMAL(20,2)
	 '
 	 EXEC(@SQL1)
 	 
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  Ratio_'+@ANIO+'_D  DECIMAL(20,5)
	 '
 	 EXEC(@SQL1)
 	 */
 	 
 	 /**************INDICADOR  EN DOLARES *********/
 	 
 	 /*
 	 SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_NOTARIO+' ADD  Indicador_D  int
	 '
 	 EXEC(@SQL1)
 	 */
 	 
 	 
 	 
 	 /*
 	PRINT('===========================================================================================================================')
	PRINT('------------------------>  ACTUALIZANDO NRO OPERACION Y MONTO DE VENTAS ACTJR. 04-02 DEL AÑO ACTUAL---- ------------------')
	PRINT('============================================================================================================================')	
  	 
 	   	 	 
 	SET @SQL1= '
 	update '+@TABLA_INCONSISTENCIA_NOTARIO+'
	set 
	NroOper_04_'+@anio+'_S=B.Cant_Soles,
	NroOper_04_'+@anio+'_D=B.Cant_Dolares,
	MtoAdq_04_'+@anio+'_S=b.Mto_Soles,
	MtoAdq_04_'+@anio+'_D=Mto_Dolares
	from '+@TABLA_INCONSISTENCIA_NOTARIO+' a,
	(
	SELECT A.num_docdec,count(*) as cantidad,
	convert(decimal(20,0),sum(case when a.COD_MONEDA=''PEN'' then 1  else  0 end)) as Cant_Soles,
	convert(decimal(20,0),sum(case when a.COD_MONEDA=''USD'' then 1  else  0 end)) as Cant_Dolares,
	convert(decimal(20,0),sum(case when a.COD_MONEDA=''-'' then 1  else  0 end)) as Cant_NF,
	SUM(a.mto_actjur) AS mto_actjur,
	convert(decimal(20,2),sum(case when a.COD_MONEDA=''PEN'' then a.mto_actjur  else  0 end)) as Mto_Soles,
	convert(decimal(20,2),sum(case when a.COD_MONEDA=''USD'' then a.mto_actjur else  0 end)) as Mto_Dolares,
	convert(decimal(20,2),sum(case when a.COD_MONEDA=''-'' then a.mto_actjur  else  0 end)) as Mto_NF
	FROM '+@tabla10+' A,'+@TABLA_INCONSISTENCIA_NOTARIO+'  B
	WHERE
	a.num_docdec=b.num_docdec collate Modern_Spanish_CI_AS 
	AND A.cod_tipactjur IN(''04'',''4'')  AND A.COD_OTORGANTE=''02''
	GROUP BY  A.num_docdec) as b
	where
	a.num_docdec=b.num_docdec collate Modern_Spanish_CI_AS
	'
	exec (@SQL1)
	
	PRINT('========================================================================================================================================')
	PRINT('------------------------> ACTUALIZANDO NRO OPERACION Y MONTO DE VENTAS ACTJR. 04-02 DEL AÑO ANTERIOR DE ANALISIS <-----------------------')
	PRINT('=========================================================================================================================================')	
	
	SET @SQL1= '
 	update '+@TABLA_INCONSISTENCIA_NOTARIO+'
	set 
	NroOper_04_'+@anio_ant+'_S=B.Cant_Soles,
	NroOper_04_'+@anio_ant+'_D=B.Cant_Dolares,
	MtoAdq_04_'+@anio_ant+'_S=b.Mto_Soles,
	MtoAdq_04_'+@anio_ant+'_D=Mto_Dolares
	from '+@TABLA_INCONSISTENCIA_NOTARIO+' a,
	(
	SELECT A.num_docdec,count(*) as cantidad,
	convert(decimal(20,0),sum(case when a.COD_MONEDA=''PEN'' then 1  else  0 end)) as Cant_Soles,
	convert(decimal(20,0),sum(case when a.COD_MONEDA=''USD'' then 1  else  0 end)) as Cant_Dolares,
	convert(decimal(20,0),sum(case when a.COD_MONEDA=''-'' then 1  else  0 end)) as Cant_NF,
	SUM(a.mto_actjur) AS mto_actjur,
	convert(decimal(20,2),sum(case when a.COD_MONEDA=''PEN'' then a.mto_actjur  else  0 end)) as Mto_Soles,
	convert(decimal(20,2),sum(case when a.COD_MONEDA=''USD'' then a.mto_actjur else  0 end)) as Mto_Dolares,
	convert(decimal(20,2),sum(case when a.COD_MONEDA=''-'' then a.mto_actjur  else  0 end)) as Mto_NF
	FROM '+@tabla14+' A,'+@TABLA_INCONSISTENCIA_NOTARIO+'  B
	WHERE
	a.num_docdec=b.num_docdec collate Modern_Spanish_CI_AS 
	AND A.cod_tipactjur IN(''04'',''4'')  AND A.COD_OTORGANTE=''02''
	GROUP BY  A.num_docdec) as b
	where
	a.num_docdec=b.num_docdec collate Modern_Spanish_CI_AS
	'
	exec (@SQL1)
	

*/
/*

	PRINT('==============================================================================================')
	PRINT('------------------------> ACTUALIZANDO RATIOS  DE NOTARIOS------------------------------------')
	PRINT('==============================================================================================')	
	
	
	SET @SQL1= '
	
		UPDATE '+@TABLA_INCONSISTENCIA_NOTARIO+' 
		SET 
		Ratio_'+@anio_ant+'_S=CASE WHEN ( MtoAdq_04_'+@anio_ant+'_S ) >0 THEN (CASE WHEN ( NroOper_04_'+@anio_ant+'_S >0 ) 
		THEN CONVERT(DECIMAL(20,5),([MtoAdq_04_'+@anio_ant+'_S]/ [NroOper_04_'+@anio_ant+'_S])) ELSE 0 END )ELSE 0 END 		,
		Ratio_'+@anio_ant+'_D=CASE WHEN ( MtoAdq_04_'+@anio_ant+'_D ) >0 THEN (CASE WHEN ( NroOper_04_'+@anio_ant+'_D >0 ) 
		THEN CONVERT(DECIMAL(20,5),([MtoAdq_04_'+@anio_ant+'_D]/ [NroOper_04_'+@anio_ant+'_D])) ELSE 0 END )ELSE 0 END ,
		
		Ratio_'+@anio+'_S=CASE WHEN ( MtoAdq_04_'+@anio+'_S ) >0 THEN (CASE WHEN ( NroOper_04_'+@anio+'_S >0 ) 
		THEN CONVERT(DECIMAL(20,5),([MtoAdq_04_'+@anio+'_S]/ [NroOper_04_'+@anio+'_S])) ELSE 0 END )ELSE 0 END ,
		Ratio_'+@anio+'_D=CASE WHEN ( MtoAdq_04_'+@anio+'_D ) >0 THEN (CASE WHEN ( NroOper_04_'+@anio+'_D >0 ) 
		THEN CONVERT(DECIMAL(20,5),([MtoAdq_04_'+@anio+'_D]/ [NroOper_04_'+@anio+'_D])) ELSE 0 END )ELSE 0 END 
					
		FROM '+@TABLA_INCONSISTENCIA_NOTARIO+' 

	'
		exec (@SQL1)


			
	PRINT('=======================================================================================================')
	PRINT('------------------------> ACTUALIZANDO EL INDICADOR DE INCONSISTENCIA DOLARES <------------------------')
	PRINT('=======================================================================================================')	

		
	SET @SQL1= '
	UPDATE '+@TABLA_INCONSISTENCIA_NOTARIO+' 
	SET INDICADOR_D=1
	FROM '+@TABLA_INCONSISTENCIA_NOTARIO+' 
	WHERE  	Ratio_'+@anio+'_D - Ratio_'+@anio_ant+'_D >=0.5
	'
	exec (@SQL1)
	
				
	PRINT('=======================================================================================================')
	PRINT('------------------------> ACTUALIZANDO EL INDICADOR DE INCONSISTENCIA SOLES <------------------------')
	PRINT('=======================================================================================================')	
	
	SET @SQL1= '
	UPDATE '+@TABLA_INCONSISTENCIA_NOTARIO+' 
	SET INDICADOR_S=1
	FROM '+@TABLA_INCONSISTENCIA_NOTARIO+' 
	WHERE  	Ratio_'+@anio+'_S - Ratio_'+@anio_ant+'_S >=0.5
	'
	exec (@SQL1)
	
		
	PRINT('=======================================================================================================')
	PRINT('------------------------> NOTARIOS CON POSIBLE ERROR CON  MONTOS GRANDES EN  SOLES <-------------------')
	PRINT('=======================================================================================================')	
		
		
		
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA_MONTO_S+''') 
	DROP TABLE '+@TABLA_INCONSISTENCIA_MONTO_S
	EXECUTE (@SQL1)
		
	SET @SQL1= '
		
	select

	a.cod_depen,A.num_docdec,D.Nombre as razon, A.num_periodo,A.cod_formul,  A.num_ordpres,  A.fec_presenta, A.cod_escritura, A.fec_numesc, 
	CASE WHEN ind_tipopenot=''1'' THEN ''ESCRITURA'' ELSE CASE WHEN ind_tipopenot=''2'' THEN ''ACTA NOTARIAL'' ELSE CASE WHEN ind_tipopenot=''3'' 
	THEN ''FORMULARIO REGISTRAL'' 	ELSE CASE WHEN ind_tipopenot=''4''  THEN ''FORMULARIO DE INSCRIPCIÓN'' ELSE '''' END  END END  END AS Nom_ind_tipopenot,
	num_actjur,dbo.f_Nom_cod_tipactjur(cod_tipactjur) AS Nom_cod_tipactjur,
	CASE WHEN COD_MONEDA=''PEN'' THEN ''SOLES'' ELSE CASE WHEN COD_MONEDA=''USD'' THEN ''DOLARES'' ELSE ''-'' END  END AS MONEDA,
	cod_tipdocoto,	num_docoto,	DBO.f_Nom_Cod_Otorgante (cod_otorgante) AS Nom_cod_otorgante,num_porcoto,mto_actjur,ind_tipopenot,COD_MONEDA,cod_tipactjur,cod_cicdec
	INTO '+@TABLA_INCONSISTENCIA_MONTO_S+'
	from 
	(
	SELECT 
	a.cod_depen,A.cod_cicdec, A.num_periodo, A.cod_formul,  A.num_ordpres,  A.fec_presenta,  A.hor_presenta, A.num_docdec, A.cod_escritura, A.fec_numesc, A.ind_tipopenot, 
	A.num_actjur, A.cod_tipactjur,  
	a.cod_otorgante, A.cod_moneda,  A.cod_tipdocoto, A.num_docoto, A.num_porcoto, A.mto_actjur ,FLOOR(A.mto_actjur) as Monto_Entera
	FROM '+@tabla1+' A,(
	SELECT num_docdec FROM '+@TABLA_INCONSISTENCIA_NOTARIO+'
	WHERE 
	(( IndIncon_NroDoc  IS NOT NULL) OR (INDICADOR_S IS NOT NULL) OR (INDICADOR_D IS NOT NULL)) ) AS B

	WHERE
	A.num_docdec=B.num_docdec  COLLATE Modern_Spanish_CI_AS AND
	LEN(FLOOR(A.mto_actjur))=7 AND
	A.COD_MONEDA=''PEN'' AND
	RIGHT(FLOOR(A.mto_actjur ),3)=''000'' and
	cod_tipactjur IN(''04'',''4'')  
	) as a left join  '+@TABLA_PADRON+' as d
	on
	a.num_docdec=d.RUC collate Modern_Spanish_CI_AS
	order by a.cod_depen,A.cod_cicdec, A.num_periodo, A.cod_formul,  A.num_ordpres,  A.fec_presenta,  A.hor_presenta, A.num_docdec, A.cod_escritura, A.fec_numesc, A.ind_tipopenot, 
 	A.cod_tipactjur,A.num_actjur,A.cod_otorgante
 
	'
 	 exec (@SQL1)
 	 
 	 
 	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA_MONTO_D+''') 
	DROP TABLE '+@TABLA_INCONSISTENCIA_MONTO_D
	EXECUTE (@SQL1)
	
 	SET @SQL1= '
	
	select
	a.cod_depen,A.num_docdec,D.Nombre as razon, A.num_periodo,A.cod_formul,  A.num_ordpres,  A.fec_presenta, A.cod_escritura, A.fec_numesc, 
	CASE WHEN ind_tipopenot=''1'' THEN ''ESCRITURA'' ELSE CASE WHEN ind_tipopenot=''2'' THEN ''ACTA NOTARIAL'' ELSE CASE WHEN ind_tipopenot=''3'' 
	THEN ''FORMULARIO REGISTRAL'' 	ELSE CASE WHEN ind_tipopenot=''4''  THEN ''FORMULARIO DE INSCRIPCIÓN'' ELSE '''' END  END END  END AS Nom_ind_tipopenot,
	num_actjur,dbo.f_Nom_cod_tipactjur(cod_tipactjur) AS Nom_cod_tipactjur,
	CASE WHEN COD_MONEDA=''PEN'' THEN ''SOLES'' ELSE CASE WHEN COD_MONEDA=''USD'' THEN ''DOLARES'' ELSE ''-'' END  END AS MONEDA,
	cod_tipdocoto,	num_docoto,	DBO.f_Nom_Cod_Otorgante (cod_otorgante) AS Nom_cod_otorgante,num_porcoto,mto_actjur,ind_tipopenot,COD_MONEDA,cod_tipactjur,cod_cicdec
	INTO '+@TABLA_INCONSISTENCIA_MONTO_D+'
	from 
	(
	SELECT 
	a.cod_depen,A.cod_cicdec, A.num_periodo, A.cod_formul,  A.num_ordpres,  A.fec_presenta,  A.hor_presenta, A.num_docdec, A.cod_escritura, A.fec_numesc, A.ind_tipopenot, 
	A.num_actjur, A.cod_tipactjur,  
	a.cod_otorgante, A.cod_moneda,  A.cod_tipdocoto, A.num_docoto, A.num_porcoto, A.mto_actjur ,FLOOR(A.mto_actjur) as Monto_Entera
	FROM '+@tabla1+' A,(
	SELECT num_docdec FROM '+@TABLA_INCONSISTENCIA_NOTARIO+'
	WHERE 
	(( IndIncon_NroDoc  IS NOT NULL) OR (INDICADOR_S IS NOT NULL) OR (INDICADOR_D IS NOT NULL)) ) AS B

	WHERE
	A.num_docdec=B.num_docdec  COLLATE Modern_Spanish_CI_AS AND
	LEN(FLOOR(A.mto_actjur))=6 AND
	A.COD_MONEDA=''USD'' AND
	RIGHT(FLOOR(A.mto_actjur ),3)=''000'' and
	cod_tipactjur IN(''04'',''4'')  
	) as a left join  '+@TABLA_PADRON+' as d
	on
	a.num_docdec=d.RUC collate Modern_Spanish_CI_AS
	order by a.cod_depen,A.cod_cicdec, A.num_periodo, A.cod_formul,  A.num_ordpres,  A.fec_presenta,  A.hor_presenta, A.num_docdec, A.cod_escritura, A.fec_numesc, A.ind_tipopenot, 
 	A.cod_tipactjur,A.num_actjur,A.cod_otorgante
 	'
 	 exec (@SQL1)
 	 
 	 
 	 	 */
 	 	 
 	 
	PRINT('==============================================================================================')
	PRINT('---------------------------------> ELIMINAMOS LAS TABLAS TEMPORALES <-------------------------')
	PRINT('==============================================================================================')
	
		
	SET @SQL1='
	--DROP TABLE '+@tabla2+';
	--DROP TABLE '+@tabla3+';
	--DROP TABLE '+@tabla4+';
	--DROP TABLE '+@tabla5+';
	--DROP TABLE '+@TABLA_INCONSISTENCIA_PRE+';
	--DROP TABLE '+@TABLA_INCONSISTENCIA_UNICAS+';
	--DROP TABLE '+@TABLA_INCONSISTENCIA+';
	
	'
	PRINT(@SQL1)
	EXEC(@SQL1)
	
	

	
	
	/*	

	PRINT('===========================================================================================================')
	PRINT('------------------------> PROCEDEMOS A JUNTAR LAS INCONSISTENCIAS NRO DOCUMENTO     <----------------------')
	PRINT('===========================================================================================================')	
	*/
	
	/*
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA_PRE+''') DROP TABLE '+@TABLA_INCONSISTENCIA_PRE
	EXECUTE (@SQL1)
		
	SET @SQL1= '
	SELECT * INTO  '+@TABLA_INCONSISTENCIA_PRE+' FROM '+@tabla3+'
	'
	--PRINT(@SQL1)
	EXEC(@SQL1)	
	
	PRINT('--> TABLA INCONSISTENCIAS PREVIAS : SELECT * FROM '+@TABLA_INCONSISTENCIA_PRE+CHAR(10))*/
	
		
	/*	--SI HUBIERA OTRA MANERA DE OTRO CASO ESPECIAL AQUI SE AGREGA	*/
	
	
	
	
	/*	--SE DEBERA METER A UNA TABLA DE UNICOS POR SI ACASO	*/
	


/*
	PRINT('==============================================================================================')
	PRINT('------------------------>   SACANDO  LAS INCONSISTENCIAS UNICAS      <----- ------------------')
	PRINT('==============================================================================================')
	
*/

	/*
	
	
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA_UNICAS+''') 
	DROP TABLE '+@TABLA_INCONSISTENCIA_UNICAS
	EXECUTE (@SQL1)
	
	SET @SQL1= '
	SELECT DISTINCT * INTO  '+@TABLA_INCONSISTENCIA_UNICAS+' FROM '+@TABLA_INCONSISTENCIA_PRE+'
	'
	EXECUTE (@SQL1)
	PRINT('--> TABLA DE INCONSISTENCIAS UNICAS : SELECT * FROM '+@TABLA_INCONSISTENCIA_UNICAS+CHAR(10))*/
	
	
	/*
  				
	PRINT('==============================================================================================')
	PRINT('------------------------> PROCEDEMOS A DAR LA ESTRUCTURA SOLICITADA     <----- ----------------')
	PRINT('===============================================================================================')	*/
	
	
	/*
	SET @SQL1= '
	 ALTER TABLE '+@TABLA_INCONSISTENCIA_UNICAS+' ADD  RAZON Varchar(150)
	 '
	 ---PRINT(@SQL1)
 	 EXEC(@SQL1)

	SET @SQL1= 'UPDATE a  SET a.razon = b.Nombre 
				FROM '+@TABLA_INCONSISTENCIA_UNICAS+' a, '+@TABLA_PADRON+' b
				WHERE 
				a.num_docdec = b.ruc collate Modern_Spanish_CI_AS
				'
	--PRINT(@SQL1)
	EXEC(@SQL1)
	
	PRINT('--> AGREGANDO RAZON A LA TABLA DE INCONSISTENCIAS UNICAS : SELECT * FROM '+@TABLA_INCONSISTENCIA_UNICAS++CHAR(10))
	*/
	
	/*

	PRINT('==============================================================================================')
	PRINT('------------------------> FORMATEAR LA ESTRUCTURA A REMITIR-----     <----- ------------------')
	PRINT('==============================================================================================')	*/
	
	/*
	SET @SQL1 = 'IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = '''+@TABLA_INCONSISTENCIA+''') 
	DROP TABLE '+@TABLA_INCONSISTENCIA
	EXECUTE (@SQL1)
	
		
	SET @SQL1= '
	
	SELECT cod_depen,num_docdec,razon,num_periodo,cod_formul,num_ordpres,fec_presenta,cod_escritura,fec_numesc,
	CASE WHEN ind_tipopenot=''1'' THEN ''ESCRITURA'' ELSE CASE WHEN ind_tipopenot=''2'' THEN ''ACTA NOTARIAL'' ELSE CASE WHEN ind_tipopenot=''3'' 
	THEN ''FORMULARIO REGISTRAL'' 	ELSE CASE WHEN ind_tipopenot=''4''  THEN ''FORMULARIO DE INSCRIPCIÓN'' ELSE '''' END  END END  END AS Nom_ind_tipopenot,
	num_actjur,dbo.f_Nom_cod_tipactjur(cod_tipactjur) AS Nom_cod_tipactjur,
	CASE WHEN COD_MONEDA=''PEN'' THEN ''SOLES'' ELSE CASE WHEN COD_MONEDA=''USD'' THEN ''DOLARES'' ELSE ''-'' END  END AS MONEDA,
	cod_tipdocoto,	num_docoto,	DBO.f_Nom_Cod_Otorgante (cod_otorgante) AS Nom_cod_otorgante,num_porcoto,mto_actjur,cod_otorgante,ind_tipopenot,COD_MONEDA,cod_tipactjur,cod_cicdec
	INTO '+@TABLA_INCONSISTENCIA+'
	FROM  '+@TABLA_INCONSISTENCIA_UNICAS+'
	
	'
	--PRINT(@SQL1)
	EXEC(@SQL1)
	PRINT('--> DANDO FORMATO A LA TABLA DE INCONSISTENCIAS FINAL : SELECT * FROM '+@TABLA_INCONSISTENCIA+CHAR(10))*/


	
	PRINT('=============================================================================')
	PRINT('---------------------------------> RESULTADO FINAL <-------------------------')
	PRINT('=============================================================================')
	
	PRINT('--> TABLA RESULTADO FINAL   : SELECT * FROM '+@TABLA_INCONSISTENCIA_NRODOC+CHAR(10))
	/*PRINT('--> TABLA RESULTADO FINAL   : SELECT * FROM '+@TABLA_INCONSISTENCIA_ITF+CHAR(10))
	PRINT('--> TABLA RESULTADO FINAL   : SELECT * FROM '+@TABLA_INCONSISTENCIA_MONTO_S+CHAR(10))
	PRINT('--> TABLA RESULTADO FINAL   : SELECT * FROM '+@TABLA_INCONSISTENCIA_MONTO_D+CHAR(10))*/
	
	
	PRINT('============================================================================================================')
	PRINT('-------------> ACTUALIZANDO EL INDICADOR DE ESTADO EN LA TABLA DETALLE DE NOTARIOS <-------------------------')
	PRINT('=============================================================================================================')
	
	
	
	
	SET @SQL1='
	UPDATE a  SET a.Ind_Estado = ''1'',A.OBS=''''
				FROM '+@tabla1+' a
	'

	EXEC(@SQL1)
	
	
	
	
	SET @SQL1='
	
	
	UPDATE a  SET a.Ind_Estado = ''0'',A.OBS=''MTO INCON''
				FROM '+@tabla1+' a, '+@TABLA_INCONSISTENCIA_NRODOC+' b
				WHERE 
				A.cod_cicdec=B.cod_cicdec and
				a.cod_formul=b.cod_formul and
				A.num_ordpres=B.num_ordpres and
				A.cod_escritura =B.cod_escritura and
				A.fec_numesc =B.fec_numesc and 
				A.ind_tipopenot =B.ind_tipopenot and
				A.num_actjur =B.num_actjur and 
				A.cod_tipactjur =B.cod_tipactjur
	'

	EXEC(@SQL1)
	
	PRINT('--> TABLA DETALLE DE NOTARIOS - IND. ESTADO ACTUALIZADO : SELECT * FROM '+@TABLA1+CHAR(10))
	
	
	PRINT('=======================================================================================================')
	PRINT('--------> ACTUALIZANDO EL INDICADOR DE ESTADO EN LA TABLA DE MONTOS UNICOS DE NOTARIOS <---------------')
	PRINT('=======================================================================================================')
	
	
	
	SET @SQL1='
	UPDATE a  SET a.Ind_Estado = ''1''
				FROM '+@tabla10+' a
	'

	EXEC(@SQL1)
	
	
	SET @SQL1='
		
				UPDATE a  SET a.Ind_Estado = ''0''
				FROM '+@tabla10+' a, '+@TABLA_INCONSISTENCIA_NRODOC+' b
				WHERE 
				A.cod_cicdec=B.cod_cicdec and
				A.num_ordpres=B.num_ordpres and
				A.cod_escritura =B.cod_escritura and
				A.fec_numesc =B.fec_numesc and 
				A.ind_tipopenot =B.ind_tipopenot and
				A.num_actjur =B.num_actjur and 
				A.cod_tipactjur =B.cod_tipactjur

	'
	EXEC(@SQL1)
	PRINT('--> TABLA  DE MONTOS UNICOS NOTARIOS - IND. ESTADO ACTUALIZADO : SELECT * FROM '+@TABLA10+CHAR(10))
		
			
	END
	
	
	
GO

