USE [db_proc]
GO

/****** Object:  StoredProcedure [dbo].[SP_TBL_INCT_NOTARIO_CONSISTENCIA_OTROS]    Script Date: 07/12/2018 11:49:34 a.m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SP_TBL_INCT_NOTARIO_CONSISTENCIA_OTROS]
@ANIO VARCHAR(4),
@TABLA_NOTARIOS VARCHAR(100), @TABLA_NOTARIOS_MONTO_UNICO VARCHAR(100), @BASE_PROCESO varchar(200) AS

BEGIN

       DECLARE @SQL VARCHAR(8000)
       
       DECLARE @tabla1 varchar(200)
       DECLARE @tabla2 varchar(200)
       DECLARE @tabla3 varchar(200)
       DECLARE @tabla4 varchar(200)
       DECLARE @tabla5 varchar(200)
       DECLARE @tabla6 varchar(200)
       DECLARE @tabla7 varchar(200)
       DECLARE @tabla8 varchar(200)
       DECLARE @tabla9 varchar(200)
       DECLARE @tabla10 varchar(200)
       DECLARE @tabla11 varchar(200)
       DECLARE @tabla12 varchar(200)
       DECLARE @tabla13 varchar(200)
       DECLARE @tabla14 varchar(200)

       SET @tabla1  = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2102actjur_'+@ANIO
       SET @tabla2 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2106bienact_'+@ANIO
       SET @tabla3 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2113otoxbien_'+@ANIO
       SET @tabla4 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2131regoto_'+@ANIO
       SET @tabla5 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t3055presentainf_'+@ANIO
       SET @tabla6 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2310escritura_'+@ANIO
       SET @tabla7 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2486libros_'+@ANIO
       SET @tabla8 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t3055presentainf_Fech_Max_'+@ANIO
       SET @tabla9 = @BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t3055presentainf_Horas_Max_'+@ANIO
       SET @tabla10 =@BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t3055presentainf_Ultima_Cabecera_'+@ANIO
       SET @tabla11 =@BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2102actjur_CRUCE_t3055presentainf_'+@ANIO
       SET @tabla12 =@BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2102actjur_CRUCE_t2106bienact_'+@ANIO
       SET @tabla13 =@BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2102actjur_CRUCE_t2131regoto_'+@ANIO
       SET @tabla14 =@BASE_PROCESO+'.dbo.TEMP_NOTARIOS_t2102actjur_CRUCE_t2113otoxbien_'+@ANIO
       
       
                     
       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS+@ANIO+'
       SET Ind_Estado=''0'',OBS= CASE WHEN LEN(OBS)>1 THEN OBS+''-''+''INC_TIPO_DOCUMENTO'' ELSE ''INC_TIPO_DOCUMENTO_0'' END 
       FROM '+@TABLA_NOTARIOS+@ANIO+'
       WHERE 
       cod_tipdocoto=0     
       '
       PRINT (@SQL)
       EXEC (@SQL)
       

       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''INC_TIPO_DOC_'+@ANIO+'_tmp_1'') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.INC_TIPO_DOC_'+@ANIO+'_tmp_1  '
       EXEC(@SQL)
       
       SET @SQL= 
       'SELECT  cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,
       cod_tipactjur,fec_presenta
       INTO '+@BASE_PROCESO+'.dbo.INC_TIPO_DOC_'+@ANIO+'_tmp_1 
       from '+@TABLA_NOTARIOS+@ANIO+' 
       WHERE cod_tipdocoto=0
       GROUP BY  cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,
       cod_tipactjur,fec_presenta'
       PRINT (@SQL)
       EXEC(@SQL)
       

       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS_MONTO_UNICO+@ANIO+'
       SET IND_ESTADO=''0''
       FROM '+@TABLA_NOTARIOS_MONTO_UNICO+@ANIO+' A,'+@BASE_PROCESO+'.dbo.INC_TIPO_DOC_'+@ANIO+'_tmp_1 B
       WHERE 
       A.cod_cicdec=B.cod_cicdec AND
       A.num_ordpres=B.num_ordpres AND 
       A.cod_escritura=B.cod_escritura AND 
       A.fec_numesc=B.fec_numesc AND 
       A.ind_tipopenot=B.ind_tipopenot AND 
       A.num_actjur=B.num_actjur AND
       A.cod_tipactjur=B.cod_tipactjur  AND
       A.fec_presenta=B.fec_presenta 
       '
       PRINT (@SQL)
       EXEC(@SQL)
       

                                                
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''cic_MARCA_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.cic_MARCA_'+@ANIO+' '
       EXEC(@SQL)


       SET @SQL= 
       'SELECT      cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta
       INTO '+@BASE_PROCESO+'.dbo.cic_MARCA_'+@ANIO+' 
       FROM '+@TABLA_NOTARIOS+@ANIO+' 
       where cod_cicotod=0
       '
       PRINT (@SQL)
       EXEC(@SQL)   
       

                            
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''CIC_INC_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.CIC_INC_'+@ANIO+' '
       EXEC(@SQL)

       SET @SQL= 
       'SELECT cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta,
       des_nomoto,  cod_cicotod,  cod_tipdocoto, COUNT(DISTINCT(num_docoto)) AS CANTIDAD 
       INTO '+@BASE_PROCESO+'.dbo.CIC_INC_'+@ANIO+' 
       FROM '+@TABLA_NOTARIOS+@ANIO+' 
       WHERE cod_cicotod>0
       GROUP BY cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta,
       des_nomoto,   cod_cicotod,cod_tipdocoto
       HAVING  COUNT(DISTINCT(num_docoto))>1
       '
       PRINT (@SQL)
       EXEC(@SQL)   

       
       /****************JUNTANDO LAS INCONSISTENCIAS DE LOS CIC *******************************/
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''INCON_NOT_CIC_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.INCON_NOT_CIC_'+@ANIO+' '
       EXEC(@SQL)
       
       
       SET @SQL= 
       'SELECT cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta
       INTO '+@BASE_PROCESO+'.dbo.INCON_NOT_CIC_'+@ANIO+' 
       FROM '+@BASE_PROCESO+'.dbo.cic_MARCA_'+@ANIO+' 
       UNION
       SELECT cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta
       FROM '+@BASE_PROCESO+'.dbo.CIC_INC_'+@ANIO+' 
       '
       PRINT (@SQL)
       EXEC(@SQL)   



       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS+@ANIO+'
       SET Ind_Estado=''0'', OBS= CASE WHEN  LEN(OBS)>1 THEN OBS+''-''+''CIC INCON'' ELSE ''CIC INCON'' END
       FROM '+@TABLA_NOTARIOS+@ANIO+' A,'+@BASE_PROCESO+'.dbo.INCON_NOT_CIC_'+@ANIO+' B
       WHERE 
       A.cod_cicdec=B.cod_cicdec AND 
       A.num_ordpres=B.num_ordpres AND 
       A.cod_escritura=B.cod_escritura AND 
       A.fec_numesc=B.fec_numesc AND 
       A.ind_tipopenot=B.ind_tipopenot AND 
       A.num_actjur=B.num_actjur AND
       A.cod_tipactjur=B.cod_tipactjur
       '
       PRINT (@SQL)
       EXEC(@SQL)


                     
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''DUPLICADOS_BIENES_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.DUPLICADOS_BIENES_'+@ANIO+' '
       EXEC(@SQL)
       
       
       SET @SQL= 
       'SELECT cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,
       num_actjur,cod_pais,cod_ubigeo_bns,cod_bienn,des_otbien,ind_tipmat,des_tipmat,ind_tbien,
       ind_oribien,num_serie,fec_adquis 
       INTO '+@BASE_PROCESO+'.dbo.DUPLICADOS_BIENES_'+@ANIO+' 
       FROM '+@TABLA_NOTARIOS+@ANIO+' 
       where cod_bienn in (''01'',''05'',''07'',''09'',''99'') AND (ISNULL(ind_tipmat,'''')<>'''' OR ISNULL(des_tipmat,'''') <>'''')
       group by cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,
       num_actjur,cod_pais,cod_ubigeo_bns,cod_bienn,des_otbien,ind_tipmat,des_tipmat,ind_tbien,
       ind_oribien,num_serie,fec_adquis
       having count(distinct(num_ordbien))>1   
       '
       PRINT (@SQL)
       EXEC(@SQL)   
       

       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS+@ANIO+'
       SET Ind_Estado=''0'',OBS= CASE WHEN LEN(OBS)>1 THEN OBS+''-''+''Bien Duplicado'' ELSE ''Bien Duplicado'' END 
       FROM '+@TABLA_NOTARIOS+@ANIO+' A,'+@BASE_PROCESO+'.dbo.DUPLICADOS_BIENES_'+@ANIO+' B
       WHERE 
       A.cod_cicdec=B.cod_cicdec AND 
       A.num_ordpres=B.num_ordpres AND 
       A.cod_escritura=B.cod_escritura AND 
       A.fec_numesc=B.fec_numesc AND 
       A.ind_tipopenot=B.ind_tipopenot AND 
       A.num_actjur=B.num_actjur AND
       isnull(A.cod_pais,'''')=isnull(B.cod_pais,'''') AND
       ISNULL(A.cod_ubigeo_bns,'''')=ISNULL(B.cod_ubigeo_bns,'''') AND
       isnull(A.cod_bienn,'''')=isnull(B.cod_bienn,'''') AND
       ISNULL(A.des_otbien,'''')=ISNULL(B.des_otbien,'''') AND
       ISNULL(A.des_otbien,'''')=ISNULL(B.des_otbien,'''') AND
       ISNULL(A.ind_tipmat,'''')=ISNULL(B.ind_tipmat,'''') AND
       ISNULL(A.ind_tbien,'''')=ISNULL(B.ind_tbien,'''') AND
       ISNULL(A.ind_oribien,'''')=ISNULL(B.ind_oribien,'''') AND
       ISNULL(A.des_tipmat,'''')=ISNULL(B.des_tipmat,'''') AND
       ISNULL(A. fec_adquis,'''')=ISNULL(B.fec_adquis,'''')
       '
       PRINT (@SQL)
       EXEC(@SQL)


                            
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''DUPLICADO_OTORGANTE_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.DUPLICADO_OTORGANTE_'+@ANIO+' '
       EXEC(@SQL)
       
       
       SET @SQL= 
       'SELECT cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,num_ordbien,cod_otorgante,cod_tipdocoto,num_docoto
       INTO '+@BASE_PROCESO+'.dbo.DUPLICADO_OTORGANTE_'+@ANIO+' 
       FROM '+@TABLA_NOTARIOS+@ANIO+' 
       group by  cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,
       num_actjur,num_ordbien,cod_otorgante,cod_tipdocoto,num_docoto
       having count(distinct(num_secotg))>1
       '
       PRINT (@SQL)
       EXEC(@SQL)   
       
             
       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS+@ANIO+'
       SET Ind_Estado=''0'',OBS= CASE WHEN LEN(OBS)>1 THEN OBS+''-''+''Otorgante Duplicado'' ELSE ''Otorgante Duplicado'' END 
       FROM '+@TABLA_NOTARIOS+@ANIO+' A,'+@BASE_PROCESO+'.dbo.DUPLICADO_OTORGANTE_'+@ANIO+' B
       WHERE 
       A.cod_cicdec=B.cod_cicdec AND 
       A.num_ordpres=B.num_ordpres AND 
       A.cod_escritura=B.cod_escritura AND 
       A.fec_numesc=B.fec_numesc AND 
       A.ind_tipopenot=B.ind_tipopenot AND 
       A.num_actjur=B.num_actjur AND
       A.num_ordbien=B.num_ordbien AND
       A.cod_otorgante=B.cod_otorgante AND
       A.cod_tipdocoto=B.cod_tipdocoto AND
       A.num_docoto=B.num_docoto 
       '
       PRINT (@SQL)
       EXEC(@SQL)


                     
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''DUPLICADO_ESCRITURA_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.DUPLICADO_ESCRITURA_'+@ANIO+' '
       EXEC(@SQL)

             
       SET @SQL= 
       'SELECT ind_tipopenot, num_actjur, cod_tipactjur, cod_moneda, 
       des_otactjur, mto_actjur, fec_inipla, fec_finpla, num_bienes, cod_banco, cod_medpag, 
       fec_minuta, ind_pago, cod_monedapag, mto_pagado_aj, fec_emision, num_documento, 
       cod_pais, cod_ubigeo_bns, cod_bienn, des_otbien, ind_tipmat, des_tipmat, 
       ind_tbien, ind_oribien, num_serie, fec_adquis, cod_tipdocoto, num_docoto, 
       cod_otorgante, num_porcoto, ind_tercera, ind_bien, num_ordenf1662, mto_pagado_oxb, 
       ind_tipper, cod_ubigeo_oto, des_nomoto, cod_cicotod, cod_valregn, cod_cicdec, 
       num_periodo, cod_formul, num_ordpres, cod_depen, fec_presenta, hor_presenta, 
       cod_tipdocdec, num_docdec, ind_estado_pdt, ind_estado_carga, ind_ultima,ind_detalle
       INTO '+@BASE_PROCESO+'.dbo.DUPLICADO_ESCRITURA_'+@ANIO+' 
       FROM '+@TABLA_NOTARIOS+@ANIO+' 
       WHERE cod_bienn in (''01'',''05'',''07'',''09'',''99'')  AND  (ISNULL(ind_tipmat,'''')<>'''' OR ISNULL(des_tipmat,'''') <>'''')
       GROUP BY  ind_tipopenot, num_actjur, cod_tipactjur, cod_moneda, 
       des_otactjur, mto_actjur, fec_inipla, fec_finpla, num_bienes, cod_banco, cod_medpag, 
       fec_minuta, ind_pago, cod_monedapag, mto_pagado_aj, fec_emision, num_documento, 
       cod_pais, cod_ubigeo_bns, cod_bienn, des_otbien, ind_tipmat, des_tipmat, 
       ind_tbien, ind_oribien, num_serie, fec_adquis, cod_tipdocoto, num_docoto, 
       cod_otorgante, num_porcoto, ind_tercera, ind_bien, num_ordenf1662, mto_pagado_oxb, 
       ind_tipper, cod_ubigeo_oto, des_nomoto, cod_cicotod, cod_valregn, cod_cicdec, 
       num_periodo, cod_formul, num_ordpres, cod_depen, fec_presenta, hor_presenta, 
       cod_tipdocdec, num_docdec, ind_estado_pdt, ind_estado_carga, ind_ultima,ind_detalle
       HAVING COUNT(DISTINCT(COD_ESCRITURA))>1
       '
       PRINT (@SQL)
       EXEC(@SQL)   
       
             
       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS+@ANIO+'
       SET Ind_Estado=''0'',OBS= CASE WHEN LEN(OBS)>1 THEN OBS+''-''+''Mas de 1 Escritura'' ELSE ''Mas de 1 Escritura'' END 
       FROM '+@TABLA_NOTARIOS+@ANIO+' A,'+@BASE_PROCESO+'.dbo.DUPLICADO_ESCRITURA_'+@ANIO+' B
       WHERE 
       isnull(a.ind_tipopenot,'''')=isnull(b.ind_tipopenot,'''') and 
       a.num_actjur=B.num_actjur and 
       isnull(a.cod_tipactjur,'''')=isnull(b.cod_tipactjur,'''') and 
       isnull(a.cod_moneda,'''')=isnull(b.cod_moneda,'''') and 
       isnull(a.des_otactjur,'''')=isnull(b.des_otactjur,'''') and 
       ISNULL(a.mto_actjur,0)=ISNULL(b.mto_actjur,0) and 
       isnull(a.fec_inipla,'''')=isnull(b.fec_inipla,'''') and 
       isnull(a.fec_finpla,'''')=isnull(b.fec_finpla,'''') and 
       a.num_bienes=b.num_bienes and 
       isnull(a.cod_banco,'''')=isnull(b.cod_banco,'''') and 
       isnull(a.cod_medpag,'''')=isnull(b.cod_medpag,'''') and 
       isnull(a.fec_minuta,'''')=isnull(b.fec_minuta,'''') and 
       isnull(a.ind_pago,'''')=isnull(b.ind_pago,'''') and 
       isnull(a.cod_monedapag,'''')=isnull(b.cod_monedapag,'''') and 
       ISNULL(a.mto_pagado_aj,0)=ISNULL(b.mto_pagado_aj,0) and 
       isnull(a.fec_emision,'''')=isnull(b.fec_emision,'''') and 
       isnull(a.num_documento,'''')=isnull(b.num_documento,'''') and 
       isnull(a.cod_pais,'''')=isnull(b.cod_pais,'''') and 
       isnull(a.cod_ubigeo_bns,'''')=isnull(b.cod_ubigeo_bns,'''') and 
       isnull(a.cod_bienn,'''')=isnull(b.cod_bienn,'''') and 
       isnull(a.des_otbien,'''')=isnull(b.des_otbien,'''') and 
       isnull(a.ind_tipmat,'''')=isnull(b.ind_tipmat,'''') and 
       isnull(a.des_tipmat,'''')=isnull(b.des_tipmat,'''') and 
       isnull(a.ind_tbien,'''')=isnull(b.ind_tbien,'''') and 
       isnull(a.ind_oribien,'''')=isnull(b.ind_oribien,'''') and 
       isnull(a.num_serie,'''')=isnull(b.num_serie,'''') and 
       isnull(a.fec_adquis,'''')=isnull(b.fec_adquis,'''') and 
       ISNULL(a.cod_tipdocoto,0)=ISNULL(b.cod_tipdocoto,0) and 
       isnull(a.num_docoto,'''')=isnull(b.num_docoto,'''') and 
       isnull(a.cod_otorgante,'''')=isnull(b.cod_otorgante,'''') and 
       a.num_porcoto=b.num_porcoto and 
       isnull(a.ind_tercera,'''')=isnull(b.ind_tercera,'''') and 
       isnull(a.ind_bien,'''')=isnull(b.ind_bien,'''') and 
       isnull(a.num_ordenf1662,'''')=isnull(b.num_ordenf1662,'''') and 
       ISNULL(a.mto_pagado_oxb,0)=ISNULL(b.mto_pagado_oxb,0) and 
       isnull(a.ind_tipper,'''')=isnull(b.ind_tipper,'''') and 
       isnull(a.cod_ubigeo_oto,'''')=isnull(b.cod_ubigeo_oto,'''') and 
       isnull(a.des_nomoto,'''')=isnull(b.des_nomoto,'''') and 
       isnull(a.cod_cicotod,'''')=isnull(b.cod_cicotod,'''') and 
       ISNULL(a.cod_valregn,0)=ISNULL(b.cod_valregn,0) and 
       a.cod_cicdec=b.cod_cicdec and 
       isnull(a.num_periodo,'''')=isnull(b.num_periodo,'''') and 
       isnull(a.cod_formul,'''')=isnull(b.cod_formul,'''') and 
       a.num_ordpres=b.num_ordpres and 
       isnull(a.cod_depen,'''')=isnull(b.cod_depen,'''') and 
       isnull(a.fec_presenta,'''')=isnull(b.fec_presenta,'''') and 
       isnull(a.hor_presenta,'''')=isnull(b.hor_presenta,'''') and 
       ISNULL(a.cod_tipdocdec,0)=ISNULL(b.cod_tipdocdec,0) and 
       isnull(a.num_docdec,'''')=isnull(b.num_docdec,'''') and 
       isnull(a.ind_estado_pdt,'''')=isnull(b.ind_estado_pdt,'''') and 
       a.ind_estado_carga=b.ind_estado_carga and 
       isnull(a.ind_ultima,'''')=isnull(b.ind_ultima,'''') and 
       isnull(a.ind_detalle,'''')=isnull(b.ind_detalle,'''')
       '
       PRINT (@SQL)
       EXEC(@SQL)


                            
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''PONER_MARCA_'+@ANIO+''') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.PONER_MARCA_'+@ANIO+' '
       EXEC(@SQL)

       
       SET @SQL= 
       'SELECT cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta
       INTO '+@BASE_PROCESO+'.dbo.PONER_MARCA_'+@ANIO+' 
       FROM '+@TABLA_NOTARIOS+@ANIO+' 
       WHERE IND_ESTADO=''0''
       GROUP BY cod_cicdec,num_ordpres,cod_escritura,fec_numesc,ind_tipopenot,num_actjur,  cod_tipactjur,  fec_presenta
       '
       PRINT (@SQL)
       EXEC(@SQL)   


       
       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS_MONTO_UNICO+@ANIO+'
      SET IND_ESTADO=''0''
       FROM '+@TABLA_NOTARIOS_MONTO_UNICO+@ANIO+' A,'+@BASE_PROCESO+'.dbo.PONER_MARCA_'+@ANIO+' B 
       WHERE 
       A.cod_cicdec=B.cod_cicdec AND
       A.num_ordpres=B.num_ordpres AND 
       A.cod_escritura=B.cod_escritura AND 
       A.fec_numesc=B.fec_numesc AND 
       A.ind_tipopenot=B.ind_tipopenot AND 
       A.num_actjur=B.num_actjur AND
       A.cod_tipactjur=B.cod_tipactjur  AND
       A.fec_presenta=B.fec_presenta 
       '
       PRINT (@SQL)
       EXEC(@SQL)
       
       
              
       SET @SQL= 
       'UPDATE '+@TABLA_NOTARIOS+@ANIO+'
      SET IND_ESTADO=''0''
       FROM '+@TABLA_NOTARIOS+@ANIO+' A,'+@BASE_PROCESO+'.dbo.PONER_MARCA_'+@ANIO+' B
       WHERE 
       A.cod_cicdec=B.cod_cicdec AND
       A.num_ordpres=B.num_ordpres AND 
       A.cod_escritura=B.cod_escritura AND 
       A.fec_numesc=B.fec_numesc AND 
       A.ind_tipopenot=B.ind_tipopenot AND 
       A.num_actjur=B.num_actjur AND
       A.cod_tipactjur=B.cod_tipactjur  AND
       A.fec_presenta=B.fec_presenta 
       '
       PRINT (@SQL)
       EXEC(@SQL)
       
             
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''INC_TIPO_DOC_'+@ANIO+'_tmp_1'') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.INC_TIPO_DOC_'+@ANIO+'_tmp_1  '
       EXEC(@SQL)
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''cic_MARCA_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.cic_MARCA_'+@ANIO+'  '
       EXEC(@SQL)
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''CIC_INC_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.CIC_INC_'+@ANIO+'  '
       EXEC(@SQL)
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''INCON_NOT_CIC_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.INCON_NOT_CIC_'+@ANIO+'  '
       EXEC(@SQL)
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''DUPLICADOS_BIENES_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.DUPLICADOS_BIENES_'+@ANIO+'  '
       EXEC(@SQL)
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''DUPLICADO_OTORGANTE_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.DUPLICADO_OTORGANTE_'+@ANIO+'  '
       EXEC(@SQL)
       
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''DUPLICADO_ESCRITURA_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.DUPLICADO_ESCRITURA_'+@ANIO+'  '
       EXEC(@SQL)
                           
       SET @SQL= 
       'IF EXISTS(SELECT * FROM '+@BASE_PROCESO+'.SYS.SYSOBJECTS WHERE NAME = ''PONER_MARCA_'+@ANIO+' '') 
       DROP TABLE '+@BASE_PROCESO+'.dbo.PONER_MARCA_'+@ANIO+'  '
       EXEC(@SQL)
       
       
       SET @SQL='
       DROP TABLE '+@tabla1+';
       DROP TABLE '+@tabla2+';
       DROP TABLE '+@tabla3+';
       DROP TABLE '+@tabla4+';
       DROP TABLE '+@tabla5+';
       DROP TABLE '+@tabla6+';
       DROP TABLE '+@tabla7+';
       DROP TABLE '+@tabla8+';
       DROP TABLE '+@tabla9+';
       DROP TABLE '+@tabla10+';
       DROP TABLE '+@tabla11+';
       DROP TABLE '+@tabla12+';
       DROP TABLE '+@tabla13+';
       DROP TABLE '+@tabla14+';
       '
       EXEC(@SQL)
       
       

       PRINT('[===========================================================================================================]'+CHAR(10))
       PRINT('[====================================== MANDAR EJECUTAR EN DB_PROCESADO ====================================]'+CHAR(10))
       PRINT('[===========================================================================================================]'+CHAR(10))


       SET @SQL=
       'USE DB_PROCESADO
       GO

       IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = ''TBL_INCT_NOTARIOS_'+@ANIO+''') 
       --DROP TABLE TBL_INCT_NOTARIOS_'+@ANIO+'
       EXEC sp_rename ''TBL_INCT_NOTARIOS_'+@ANIO+''',''TBL_INCT_NOTARIOS_'+@ANIO+'_ANT''
       
                    
       CREATE TABLE [dbo].[TBL_INCT_NOTARIOS_'+@ANIO+']
       (
       [cod_escritura] [char](10) NOT NULL,
       [fec_numesc] [date] NOT NULL,
       [ind_tipopenot] [char](1) NOT NULL,
       [num_actjur] [smallint] NOT NULL,
       [cod_tipactjur] [char](2) NULL,
       [cod_moneda] [char](3) NULL,
       [des_otactjur] [char](30) NULL,
       [mto_actjur] [numeric](15, 2) NULL,
       [fec_inipla] [date] NULL,
       [fec_finpla] [date] NULL,
       [num_bienes] [int] NULL,
       [cod_banco] [char](2) NULL,
       [cod_medpag] [char](3) NULL,
       [fec_minuta] [date] NULL,
       [ind_pago] [smallint] NULL,
       [cod_monedapag] [char](3) NULL,
       [mto_pagado_aj] [numeric](15, 2) NULL,
       [fec_emision] [date] NULL,
       [num_documento] [varchar](25) NULL,
       [num_ordbien] [smallint] NOT NULL,
       [cod_pais] [char](3) NULL,
       [cod_ubigeo_bns] [char](6) NULL,
       [cod_bienn] [char](2) NOT NULL,
       [des_otbien] [varchar](30) NULL,
       [ind_tipmat] [char](1) NULL,
       [des_tipmat] [varchar](20) NULL,
       [ind_tbien] [char](1) NULL,
       [ind_oribien] [char](1) NULL,
       [num_serie] [varchar](20) NULL,
       [fec_adquis] [date] NULL,
       [cod_tipdocoto] [smallint] NOT NULL,
       [num_docoto] [char](15) NOT NULL,
       [num_secotg] [smallint] NOT NULL,
       [cod_otorgante] [char](2) NOT NULL,
       [num_porcoto] [numeric](5, 2) NULL,
       [ind_tercera] [char](1) NULL,
       [ind_bien] [char](1) NULL,
       [num_ordenf1662] [varchar](10) NULL,
       [mto_pagado_oxb] [numeric](15, 2) NULL,
       [ind_tipper] [char](1) NULL,
       [cod_ubigeo_oto] [char](6) NULL,
       [des_nomoto] [varchar](80) NULL,
       [cod_cicotod] [int] NULL,
       [cod_valregn] [smallint] NULL,
       [cod_cicdec] [int] NOT NULL,
       [num_periodo] [char](6) NOT NULL,
       [cod_formul] [char](4) NOT NULL,
       [num_ordpres] [int] NOT NULL,
       [cod_depen] [char](4) NOT NULL,
       [fec_presenta] [date] NULL,
       [hor_presenta] [char](8) NULL,
       [cod_tipdocdec] [smallint] NULL,
       [num_docdec] [char](15) NULL,
       [ind_estado_pdt] [char](1) NULL,
       [ind_estado_carga] [smallint] NULL,
       [ind_ultima] [char](1) NULL,
       [ind_detalle] [char](1) NULL,
       [Ind_Bienes] [varchar](1) NOT NULL,
       [Ind_Estado] [varchar](1) NOT NULL,
       [Obs] [varchar](150)  NULL
       ) 
       ON [PRIMARY]

       CREATE INDEX IND_NOTARIO ON DBO.[TBL_INCT_NOTARIOS_'+@ANIO+']  (cod_cicotod)


       IF EXISTS(SELECT * FROM SYS.SYSOBJECTS WHERE NAME = ''TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO'') 
       --DROP TABLE TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO
       EXEC sp_rename ''TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO'',''TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO_ANT''
       

       CREATE TABLE [dbo].[TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO]
       (
       [cod_depen] [char](4) NULL,
       [cod_cicdec] [int] NOT NULL,
       [num_docdec] [char](15) NULL,
       [num_ordpres] [int] NOT NULL,
       [fec_presenta] [date] NOT NULL,
       [ind_tipopenot] [char](1) NOT NULL,
       [cod_tipactjur] [char](2) NULL,
       [cod_moneda] [char](3) NULL,
       [fec_numesc] [date] NOT NULL,
       [cod_escritura] [char](10) NOT NULL,
       [num_actjur] [smallint] NOT NULL,
       [cod_cicotod] [int] NULL,
       [cod_tipdocoto] [smallint] NOT NULL,
       [num_docoto] [char](15) NOT NULL,
       [cod_otorgante] [char](2) NOT NULL,
       [num_porcoto] [decimal](20,2) NULL,
       [mto_actjur] [decimal](20,2) NULL,
       [num_bienes] [int] NULL,
       [Ind_Estado] [varchar](1) NOT NULL
       ) 
       ON [PRIMARY]

       CREATE INDEX IND_NOTARIO ON DBO.[TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO]  (cod_cicotod,cod_tipactjur,cod_otorgante)


       INSERT INTO [dbo].[TBL_INCT_NOTARIOS_'+@ANIO+']
       SELECT * FROM '+@BASE_PROCESO+'.dbo.'+@TABLA_NOTARIOS+@ANIO+'

       INSERT INTO [dbo].[TBL_INCT_NOTARIOS_'+@ANIO+'_MONTO_UNICO]
       SELECT * FROM '+@BASE_PROCESO+'.dbo.'+@TABLA_NOTARIOS_MONTO_UNICO+@ANIO+'
       '
       PRINT (@SQL)
       END


GO

